#include <iostream>

enum Mesh {SPHERE,BOX,TORUS};
enum Shapes {CUBE,CYLINDER,SPHERE};

int main()
{

}