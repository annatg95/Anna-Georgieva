#include <stdio.h>

int main(int argc, char *argv[]) 
{
	double i[6];
	printf("sizeof(i) %ld",sizeof(i)/sizeof(double));	
}