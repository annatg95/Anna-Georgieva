#Animation Software Engineering

This repository is used to contain code used in the ASE unit, it will be updated frequently with new code used in the lectures.

The lecture notes can be found on the website [here](http://nccastaff.bournemouth.ac.uk/jmacey/ASE/index.html)
