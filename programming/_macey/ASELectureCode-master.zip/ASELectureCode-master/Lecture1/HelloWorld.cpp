#include <iostream>
#include <cstdlib>

int main()
{
	std::cout<<"Hello World"<<std::endl;
	return EXIT_SUCCESS;
}