#ifndef EXTERNAL_H__
#define EXTERNAL_H__

int foo(int i);
int foo2(int i);

#endif
