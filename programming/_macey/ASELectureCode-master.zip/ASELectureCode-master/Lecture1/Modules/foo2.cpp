int foo2(int i)
{
return i*20;

}