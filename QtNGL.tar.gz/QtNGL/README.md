#QtNGL
![alt tag](http://nccastaff.bournemouth.ac.uk/jmacey/GraphicsLib/Demos/QtNGL.png)

How to use the Qt GUI with NGL
