var searchData=
[
  ['centralwidget',['centralwidget',['../class_ui___main_window.html#a356f1cf3ebda15f1fac59467ee081b74',1,'Ui_MainWindow']]],
  ['cohlabel',['CohLabel',['../class_ui___main_window.html#a01501972aefcdcf084c2208b0e368129',1,'Ui_MainWindow']]]
];
