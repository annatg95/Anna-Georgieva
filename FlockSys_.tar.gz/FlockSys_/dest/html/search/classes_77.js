var searchData=
[
  ['winparams',['WinParams',['../struct_win_params.html',1,'']]]
];
