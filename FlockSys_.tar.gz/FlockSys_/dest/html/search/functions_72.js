var searchData=
[
  ['removefish',['removeFish',['../class_flock.html#a305ae33798578f62f4901127ede43a8d',1,'Flock::removeFish()'],['../class_n_g_l_scene.html#a94151a1b676f6cf0c800723d0d7fbbe8',1,'NGLScene::removeFish()']]],
  ['resizegl',['resizeGL',['../class_n_g_l_scene.html#a7505fac688fe82b4f99e601043eb7764',1,'NGLScene']]],
  ['retranslateui',['retranslateUi',['../class_ui___main_window.html#a097dd160c3534a204904cb374412c618',1,'Ui_MainWindow']]],
  ['reverse',['reverse',['../class_fish.html#a82324573eb5dc5f977329ccc3cb0e714',1,'Fish']]],
  ['rotate',['rotate',['../class_fish.html#a439266d66d537fa4a31a63396b31952e',1,'Fish']]]
];
