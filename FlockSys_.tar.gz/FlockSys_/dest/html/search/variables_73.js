var searchData=
[
  ['s_5fdrawgb',['s_drawGB',['../class_ui___main_window.html#a800f03f37832866499b6565c8a5b073a',1,'Ui_MainWindow']]],
  ['s_5fmainwindowgridlayout',['s_mainWindowGridLayout',['../class_ui___main_window.html#ae7902f78acf2ddd14bbda720ac54c450',1,'Ui_MainWindow']]],
  ['sep',['sep',['../class_ui___main_window.html#aa6dbc9500ad84e7102926da2b8db4abc',1,'Ui_MainWindow']]],
  ['seplabel',['SepLabel',['../class_ui___main_window.html#a2a11d978cff8b34bd159eade789cce08',1,'Ui_MainWindow']]],
  ['spinxface',['spinXFace',['../struct_win_params.html#ae834d382a91e06699778caf8abf8b6a0',1,'WinParams']]],
  ['spinyface',['spinYFace',['../struct_win_params.html#adf538a60ecec846bb85fb790cdf02ef6',1,'WinParams']]],
  ['statusbar',['statusbar',['../class_ui___main_window.html#a1687cceb1e2787aa1f83e50433943a91',1,'Ui_MainWindow']]],
  ['stopf',['stopF',['../class_ui___main_window.html#a781aea69e66f9056a823241b23945979',1,'Ui_MainWindow']]],
  ['stringdata0',['stringdata0',['../structqt__meta__stringdata___main_window__t.html#ad15de9853389addc95ff360713662d89',1,'qt_meta_stringdata_MainWindow_t::stringdata0()'],['../structqt__meta__stringdata___n_g_l_scene__t.html#aa92a903ccba09ce3dda023c8d3f02b21',1,'qt_meta_stringdata_NGLScene_t::stringdata0()']]]
];
