var searchData=
[
  ['width',['width',['../struct_win_params.html#abe7daa1f3fc56dc639141bcbee759c02',1,'WinParams']]]
];
