var searchData=
[
  ['obstacle',['Obstacle',['../class_obstacle.html',1,'Obstacle'],['../class_obstacle.html#a072609f98bf25fe24729cfbcc602422e',1,'Obstacle::Obstacle()']]],
  ['obstacle_2ecpp',['Obstacle.cpp',['../_obstacle_8cpp.html',1,'']]],
  ['obstacle_2eh',['Obstacle.h',['../_obstacle_8h.html',1,'']]],
  ['origx',['origX',['../struct_win_params.html#ab9ddf234ba11eb4460eb48469cd73c3a',1,'WinParams']]],
  ['origxpos',['origXPos',['../struct_win_params.html#ab07a11274084415333c1fd0a5fc03667',1,'WinParams']]],
  ['origy',['origY',['../struct_win_params.html#a9e4ef1b5ef96c1f6bbe46bb10c11d59b',1,'WinParams']]],
  ['origypos',['origYPos',['../struct_win_params.html#a5dc76afc1f5486221ee40eee3cb9a5ac',1,'WinParams']]]
];
