var searchData=
[
  ['height',['height',['../struct_win_params.html#a9b7c0ae0270bc1f7cfad6d95524b886b',1,'WinParams']]],
  ['horizontalspacer_5f2',['horizontalSpacer_2',['../class_ui___main_window.html#a9a022556cf8ce3fa47e51d79cb222ab0',1,'Ui_MainWindow']]]
];
