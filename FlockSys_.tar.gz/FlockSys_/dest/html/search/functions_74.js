var searchData=
[
  ['textinputread',['textInputRead',['../class_main_window.html#ab7312477100340bae8aae94cfb22ad37',1,'MainWindow']]]
];
