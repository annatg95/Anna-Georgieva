var searchData=
[
  ['updatevelo',['updateVelo',['../class_fish.html#ae49a78cbf9d05a500f422c7025b87523',1,'Fish']]]
];
