var searchData=
[
  ['origx',['origX',['../struct_win_params.html#ab9ddf234ba11eb4460eb48469cd73c3a',1,'WinParams']]],
  ['origxpos',['origXPos',['../struct_win_params.html#ab07a11274084415333c1fd0a5fc03667',1,'WinParams']]],
  ['origy',['origY',['../struct_win_params.html#a9e4ef1b5ef96c1f6bbe46bb10c11d59b',1,'WinParams']]],
  ['origypos',['origYPos',['../struct_win_params.html#a5dc76afc1f5486221ee40eee3cb9a5ac',1,'WinParams']]]
];
