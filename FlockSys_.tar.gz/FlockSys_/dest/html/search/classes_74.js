var searchData=
[
  ['textinput',['textInput',['../structtext_input.html',1,'']]]
];
