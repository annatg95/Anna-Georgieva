var searchData=
[
  ['letter',['letter',['../structtext_input.html#aaa1edff48ed1db61a0f2032b8ea032a1',1,'textInput']]]
];
