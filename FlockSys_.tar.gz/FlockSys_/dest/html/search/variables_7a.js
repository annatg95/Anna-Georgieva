var searchData=
[
  ['zoom',['ZOOM',['../_window_params_8h.html#ae22a6b0e6e3792d5be37b68c1ca773f5',1,'WindowParams.h']]]
];
