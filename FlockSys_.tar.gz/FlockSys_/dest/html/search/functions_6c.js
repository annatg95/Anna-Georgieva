var searchData=
[
  ['loadmatricestoshader',['loadMatricesToShader',['../class_fish.html#a28763352e923df9c859d50ffab62cdbb',1,'Fish::loadMatricesToShader()'],['../class_obstacle.html#ad43ed311db3d6cf0173940837d4dde4c',1,'Obstacle::loadMatricesToShader()']]]
];
