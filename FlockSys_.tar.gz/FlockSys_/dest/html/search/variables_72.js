var searchData=
[
  ['rotate',['rotate',['../struct_win_params.html#a255e3c376110315e2a4ff63ccc312360',1,'WinParams']]]
];
