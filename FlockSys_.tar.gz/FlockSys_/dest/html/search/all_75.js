var searchData=
[
  ['ui',['Ui',['../namespace_ui.html',1,'']]],
  ['ui_5fmainwindow',['Ui_MainWindow',['../class_ui___main_window.html',1,'']]],
  ['ui_5fmainwindow_2eh',['ui_MainWindow.h',['../ui___main_window_8h.html',1,'']]],
  ['updatevelo',['updateVelo',['../class_fish.html#ae49a78cbf9d05a500f422c7025b87523',1,'Fish']]]
];
