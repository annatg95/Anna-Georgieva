var searchData=
[
  ['initializegl',['initializeGL',['../class_n_g_l_scene.html#aab2b866db534d286a56cc2240ed98790',1,'NGLScene']]],
  ['ishit',['isHit',['../class_fish.html#ae686f01a62a6a80e1ff436f3c46d25e0',1,'Fish']]],
  ['isitneighbour',['isItNeighbour',['../class_fish.html#aeb8a6489686030867529c3d25b5605ef',1,'Fish']]]
];
