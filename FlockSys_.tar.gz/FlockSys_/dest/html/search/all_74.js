var searchData=
[
  ['textbrowser',['textBrowser',['../class_ui___main_window.html#a2c789c07fa5fc1cee05aae8df52bb02d',1,'Ui_MainWindow']]],
  ['textinput',['textInput',['../structtext_input.html',1,'']]],
  ['textinputread',['textInputRead',['../class_main_window.html#ab7312477100340bae8aae94cfb22ad37',1,'MainWindow']]],
  ['translate',['translate',['../struct_win_params.html#adcfa86195240b478c94bfecc5e33e8e7',1,'WinParams']]]
];
