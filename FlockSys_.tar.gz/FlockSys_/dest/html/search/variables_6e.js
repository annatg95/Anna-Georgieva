var searchData=
[
  ['neigh',['neigh',['../class_ui___main_window.html#af448dab95635cea6db1ca36f2f8d0c1a',1,'Ui_MainWindow']]]
];
