var searchData=
[
  ['data',['data',['../structqt__meta__stringdata___main_window__t.html#a728217305ebd7d8895235c2038c4ed28',1,'qt_meta_stringdata_MainWindow_t::data()'],['../structqt__meta__stringdata___n_g_l_scene__t.html#a79a2ed7018824f7fe8b99d64a05be0a8',1,'qt_meta_stringdata_NGLScene_t::data()']]]
];
