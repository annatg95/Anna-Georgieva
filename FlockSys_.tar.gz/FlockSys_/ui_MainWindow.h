/********************************************************************************
** Form generated from reading UI file 'MainWindow.ui'
**
** Created by: Qt User Interface Compiler version 5.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QGridLayout *s_mainWindowGridLayout;
    QSpacerItem *horizontalSpacer_2;
    QGroupBox *s_drawGB;
    QGridLayout *gridLayout_2;
    QLabel *info1;
    QDoubleSpinBox *m_separation;
    QLabel *sep;
    QLabel *SepLabel;
    QLabel *neigh;
    QPushButton *m_simulate;
    QPushButton *m_stop;
    QLabel *ApplyF;
    QDoubleSpinBox *m_aliForce;
    QDoubleSpinBox *m_neighbour;
    QPushButton *m_addFish;
    QLabel *AliLabel;
    QDoubleSpinBox *m_sepForce;
    QDoubleSpinBox *m_cohForce;
    QLabel *stopF;
    QLabel *CohLabel;
    QCheckBox *m_RP;
    QCheckBox *m_showBS2;
    QPushButton *m_rmFish;
    QCheckBox *m_showBB2;
    QTextBrowser *textBrowser;
    QLabel *info3;
    QLabel *info2;
    QLabel *info4;
    QPushButton *m_yourTxt;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(1124, 748);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(MainWindow->sizePolicy().hasHeightForWidth());
        MainWindow->setSizePolicy(sizePolicy);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        s_mainWindowGridLayout = new QGridLayout(centralwidget);
        s_mainWindowGridLayout->setObjectName(QStringLiteral("s_mainWindowGridLayout"));
        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        s_mainWindowGridLayout->addItem(horizontalSpacer_2, 0, 0, 2, 1);

        s_drawGB = new QGroupBox(centralwidget);
        s_drawGB->setObjectName(QStringLiteral("s_drawGB"));
        QSizePolicy sizePolicy1(QSizePolicy::Fixed, QSizePolicy::Preferred);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(s_drawGB->sizePolicy().hasHeightForWidth());
        s_drawGB->setSizePolicy(sizePolicy1);
        s_drawGB->setMinimumSize(QSize(0, 0));
        s_drawGB->setMaximumSize(QSize(300, 800));
        gridLayout_2 = new QGridLayout(s_drawGB);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        info1 = new QLabel(s_drawGB);
        info1->setObjectName(QStringLiteral("info1"));
        info1->setEnabled(true);
        info1->setMaximumSize(QSize(250, 100));
        info1->setScaledContents(false);
        info1->setWordWrap(true);

        gridLayout_2->addWidget(info1, 0, 1, 1, 2);

        m_separation = new QDoubleSpinBox(s_drawGB);
        m_separation->setObjectName(QStringLiteral("m_separation"));

        gridLayout_2->addWidget(m_separation, 11, 2, 1, 1);

        sep = new QLabel(s_drawGB);
        sep->setObjectName(QStringLiteral("sep"));

        gridLayout_2->addWidget(sep, 11, 1, 1, 1);

        SepLabel = new QLabel(s_drawGB);
        SepLabel->setObjectName(QStringLiteral("SepLabel"));

        gridLayout_2->addWidget(SepLabel, 9, 1, 1, 1);

        neigh = new QLabel(s_drawGB);
        neigh->setObjectName(QStringLiteral("neigh"));

        gridLayout_2->addWidget(neigh, 10, 1, 1, 1);

        m_simulate = new QPushButton(s_drawGB);
        m_simulate->setObjectName(QStringLiteral("m_simulate"));

        gridLayout_2->addWidget(m_simulate, 13, 1, 1, 1);

        m_stop = new QPushButton(s_drawGB);
        m_stop->setObjectName(QStringLiteral("m_stop"));

        gridLayout_2->addWidget(m_stop, 13, 2, 1, 1);

        ApplyF = new QLabel(s_drawGB);
        ApplyF->setObjectName(QStringLiteral("ApplyF"));

        gridLayout_2->addWidget(ApplyF, 12, 1, 1, 1);

        m_aliForce = new QDoubleSpinBox(s_drawGB);
        m_aliForce->setObjectName(QStringLiteral("m_aliForce"));
        m_aliForce->setMaximum(30);

        gridLayout_2->addWidget(m_aliForce, 7, 2, 1, 1);

        m_neighbour = new QDoubleSpinBox(s_drawGB);
        m_neighbour->setObjectName(QStringLiteral("m_neighbour"));

        gridLayout_2->addWidget(m_neighbour, 10, 2, 1, 1);

        m_addFish = new QPushButton(s_drawGB);
        m_addFish->setObjectName(QStringLiteral("m_addFish"));

        gridLayout_2->addWidget(m_addFish, 14, 2, 1, 1);

        AliLabel = new QLabel(s_drawGB);
        AliLabel->setObjectName(QStringLiteral("AliLabel"));

        gridLayout_2->addWidget(AliLabel, 7, 1, 1, 1);

        m_sepForce = new QDoubleSpinBox(s_drawGB);
        m_sepForce->setObjectName(QStringLiteral("m_sepForce"));

        gridLayout_2->addWidget(m_sepForce, 9, 2, 1, 1);

        m_cohForce = new QDoubleSpinBox(s_drawGB);
        m_cohForce->setObjectName(QStringLiteral("m_cohForce"));
        m_cohForce->setMaximum(30);
        m_cohForce->setSingleStep(1);

        gridLayout_2->addWidget(m_cohForce, 8, 2, 1, 1);

        stopF = new QLabel(s_drawGB);
        stopF->setObjectName(QStringLiteral("stopF"));

        gridLayout_2->addWidget(stopF, 12, 2, 1, 1);

        CohLabel = new QLabel(s_drawGB);
        CohLabel->setObjectName(QStringLiteral("CohLabel"));

        gridLayout_2->addWidget(CohLabel, 8, 1, 1, 1);

        m_RP = new QCheckBox(s_drawGB);
        m_RP->setObjectName(QStringLiteral("m_RP"));

        gridLayout_2->addWidget(m_RP, 14, 1, 1, 1);

        m_showBS2 = new QCheckBox(s_drawGB);
        m_showBS2->setObjectName(QStringLiteral("m_showBS2"));

        gridLayout_2->addWidget(m_showBS2, 16, 1, 1, 1);

        m_rmFish = new QPushButton(s_drawGB);
        m_rmFish->setObjectName(QStringLiteral("m_rmFish"));

        gridLayout_2->addWidget(m_rmFish, 15, 2, 1, 1);

        m_showBB2 = new QCheckBox(s_drawGB);
        m_showBB2->setObjectName(QStringLiteral("m_showBB2"));

        gridLayout_2->addWidget(m_showBB2, 15, 1, 1, 1);

        textBrowser = new QTextBrowser(s_drawGB);
        textBrowser->setObjectName(QStringLiteral("textBrowser"));
        textBrowser->setMaximumSize(QSize(250, 16777215));

        gridLayout_2->addWidget(textBrowser, 3, 1, 1, 2);

        info3 = new QLabel(s_drawGB);
        info3->setObjectName(QStringLiteral("info3"));
        info3->setMinimumSize(QSize(250, 0));
        info3->setMaximumSize(QSize(250, 16777215));
        info3->setWordWrap(true);

        gridLayout_2->addWidget(info3, 2, 1, 1, 2);

        info2 = new QLabel(s_drawGB);
        info2->setObjectName(QStringLiteral("info2"));
        info2->setMaximumSize(QSize(250, 250));
        info2->setScaledContents(false);
        info2->setWordWrap(true);

        gridLayout_2->addWidget(info2, 1, 1, 1, 2);

        info4 = new QLabel(s_drawGB);
        info4->setObjectName(QStringLiteral("info4"));
        info4->setMinimumSize(QSize(100, 0));

        gridLayout_2->addWidget(info4, 6, 1, 1, 2);

        m_yourTxt = new QPushButton(s_drawGB);
        m_yourTxt->setObjectName(QStringLiteral("m_yourTxt"));

        gridLayout_2->addWidget(m_yourTxt, 5, 1, 1, 2);


        s_mainWindowGridLayout->addWidget(s_drawGB, 0, 1, 1, 1);

        MainWindow->setCentralWidget(centralwidget);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QStringLiteral("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "Flocking System", 0));
        s_drawGB->setTitle(QApplication::translate("MainWindow", "Flocking Settings", 0));
        info1->setText(QApplication::translate("MainWindow", "<html><head/><body><p>1.Click start to form a Flock /set values/. Values will be displayed below.</p></body></html>", 0));
        sep->setText(QApplication::translate("MainWindow", "Separation Distance", 0));
        SepLabel->setText(QApplication::translate("MainWindow", "Separation F", 0));
        neigh->setText(QApplication::translate("MainWindow", "Neighbour Distance", 0));
        m_simulate->setText(QApplication::translate("MainWindow", "Start", 0));
        m_stop->setText(QApplication::translate("MainWindow", "Stop", 0));
        ApplyF->setText(QApplication::translate("MainWindow", "Apply the Forces", 0));
        m_addFish->setText(QApplication::translate("MainWindow", "Add FIsh", 0));
        AliLabel->setText(QApplication::translate("MainWindow", "Alignment F", 0));
        stopF->setText(QApplication::translate("MainWindow", "Stop the Forces", 0));
        CohLabel->setText(QApplication::translate("MainWindow", "Cohesion F", 0));
        m_RP->setText(QApplication::translate("MainWindow", "Resume/Pause", 0));
        m_showBS2->setText(QApplication::translate("MainWindow", "ShowBSphere", 0));
        m_rmFish->setText(QApplication::translate("MainWindow", "Remove Fish", 0));
        m_showBB2->setText(QApplication::translate("MainWindow", "ShowBBox", 0));
        info3->setText(QApplication::translate("MainWindow", "<html><head/><body><p>3. Change the values for every Force /range 0-30/. Values will be displayed in the spin boxes.</p></body></html>", 0));
        info2->setText(QApplication::translate("MainWindow", "<html><head/><body><p>2. Click Open txtFile to load values from your own textFile /load values/. Values will be displayed below.</p></body></html>", 0));
        info4->setText(QApplication::translate("MainWindow", "Change the Force Values", 0));
        m_yourTxt->setText(QApplication::translate("MainWindow", "Open txtFIle", 0));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
