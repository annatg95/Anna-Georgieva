#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QString>
#include <QTextStream>
#include "NGLScene.h"
/**
 * @file MainWindow.h
 *
 * @brief MainWindow class for the GUI.
 *
 * @author Jon Macey,Anna Georgieva
 *
 *  Main Window sample taken from  QtNGL Demo available https://github.com/NCCA/QtNGL
 *
 */


/*struct for the text files
*   id- whole number, example 1,2,3
*   letter - name, example AlignmentForce
*   value - double number of the force, example 20.0
*
*/
struct textInput
{
    int id;
    QString letter;
    double value;
};

namespace Ui {class MainWindow;}

class MainWindow : public QMainWindow
{
Q_OBJECT
public:
   explicit MainWindow(QWidget *parent = 0);
   ~MainWindow();

    // @brief function that stores the input in the structure declared above
    // @params takes a string and the active stream
   void textInputRead(textInput *_a, QTextStream &_in);

private:
   // ui form
    Ui::MainWindow *m_ui;

    //ngl context
    NGLScene *m_gl;

    //filename string address
    QString filename;

private slots :
    //button to stop the flocking forces
    void on_m_stop_clicked();

    //button to start the flocking forces
    void on_m_simulate_clicked();

    //button to read values from your own text file
    void on_m_yourTxt_clicked();
};

#endif // MAINWINDOW_H
