#ifndef NGLSCENE_H_
#define NGLSCENE_H_

#include <ngl/BBox.h>
#include <ngl/Camera.h>
#include <ngl/Text.h>
#include <ngl/Transformation.h>
#include <ngl/Vec3.h>
#include <ngl/VAOFactory.h>
#include <ngl/SimpleVAO.h>
#include <ngl/ShaderLib.h>

#include "Flock.h"
#include "Obstacle.h"

#include "WindowParams.h"
#include <QEvent>
#include <QResizeEvent>
#include <QOpenGLWidget>
#include <memory>

/**
 * @file NGLScene.h
 *
 * @brief MainWindow class for the GUI.
 *
 * @author Jon Macey, Anna Georgieva
 *
 * NGLSCENE taken from  QtNGL Demo available https://github.com/NCCA/QtNGL
 * BBOX and Rays exmaples taken from the Collisions demo available https://github.com/NCCA/Collisions
 *
 */

class NGLScene : public QOpenGLWidget
{
Q_OBJECT
public :
    /*  @brief NGLScene user defined constructor  */
    /*  @params - widget window, filename, texturename, number of fish */
    /*------------------------------------------------------*/
    NGLScene(QWidget *_parent ,const std::string &_oname, const std::string &_tname, int n_fish);

    /*  @brief NGLScene destructor  */
    /*  @params --- */
    /*------------------------------------------------------*/
    ~NGLScene();

    /*  @brief initialize GL contex  */
    /*  @params ---*/
    /*------------------------------------------------------*/
    void initializeGL();

    /*  @brief resize the window  */
    /*  @params ---*/
    /*------------------------------------------------------*/
    void resizeGL(int _w , int _h);

    /*  @brief draw every object  */
    /*  @params ---*/
    /*------------------------------------------------------*/
    void paintGL();

public slots:

    /*  @brief add a fish  */
    /*  @params ---*/
    /*------------------------------------------------------*/
    void addFish(){m_flock->addFish();}

    /*  @brief remove a fish */
    /*  @params ---*/
    /*------------------------------------------------------*/
    void removeFish(){m_flock->removeFish();}

    /*  @brief sets all the forces */
    /*  @params - force*/
    /*------------------------------------------------------*/
    void setAliForce(double force_in){m_flock->setAF(force_in);}
    void setCohForce(double force_in){m_flock->setCF(force_in);}
    void setSepForce(double force_in){m_flock->setSF(force_in);}
    void setSepD(double _sepD){m_flock->setSepD(_sepD);}
    void setNeighD(double _neighD){m_flock->setNeighD(_neighD);}

    /*  @brief shows/hides BBox/ BSphere */
    /*  @params - boolean state*/
    /*------------------------------------------------------*/
    void showHideBB(int state){state ? m_flock->showHideBB(1) : m_flock->showHideBB(0);}
    void showHideBS(int state){state ? m_flock->showHideBS(1) : m_flock->showHideBS(0);}

    /*  @brief set the animation */
    /*  @params - boolean state*/
    /*------------------------------------------------------*/
    void setAnim(int state){state ? m_animate=false : m_animate=true;}


protected:
    //Mouse Matrix
    ngl::Mat4 m_mouseGlobalTX;

    // window
    WinParams m_win;

    //coordinates of the saved mouse position
    ngl::Vec3 m_mouseClickPos;

    //coordinates of the mouse position connected to the shaders
    ngl::Vec3 m_modelPos;

    //main camera
    ngl::Camera m_cam;

    //transformation connected to the shaders
    ngl::Transformation m_transform;

private :
    //obstacle obj
    std::unique_ptr<Obstacle> m_obstacle;

    //bounding box
    std::unique_ptr<ngl::BBox> m_bbox;

    //address name of the obj
    std::string m_objFileName;

    //address name of the texture
    std::string m_textureFileName;

    //unique pointer of type FLOCK
    std::unique_ptr<Flock> m_flock;

    //unique pointer of Text displayed
    std::unique_ptr<ngl::Text> m_text;

    //number of fish
    uint m_numFish;


    //apply colour shader for the box and the 3 xyz axes
    void loadMatricesToColourShader();

    //apply texture shader for the obj's
    void loadMatricesToShader();

    //save the timer frames
    int m_fishUpdateTimer;

    //boolean state for animating the program
    bool m_animate;

    //xyz coordinates so that i dont get lost
    ngl::Vec3 m_rayStart,m_rayStart2,m_rayStart3;
    ngl::Vec3 m_rayEnd,m_rayEnd2,m_rayEnd3;

    //reset the 3 rays
    void resetRay();

    //update the scene
    void updateScene();

    //handiling all the mouse event
    void mouseMoveEvent (QMouseEvent * _event );
    void mousePressEvent ( QMouseEvent *_event);
    void mouseReleaseEvent ( QMouseEvent *_event );
    void wheelEvent( QWheelEvent *_event);
    void timerEvent(QTimerEvent *_event) override;
};

#endif
