#ifndef OBSTACLE_H
#define OBSTACLE_H

#include <string>
#include <memory>
#include <cmath>
#include <limits>

#include <ngl/Camera.h>
#include <ngl/Obj.h>
#include <ngl/Random.h>
#include <ngl/Transformation.h>
#include <ngl/NGLStream.h>
#include <ngl/ShaderLib.h>
#include <ngl/Random.h>

/**
 * @file Obstacle.h
 *
 * @brief Obstacle class that draws a obstacle in the world.
 *
 * @author Jon Macey,Anna Georgieva
 *
 *  exmaple taken from ObjDemo https://github.com/NCCA/ObjDemo
 */

//in progress, not finished

class Obstacle
{
public:
    Obstacle(const std::string &_fname, const std::string &_tname);
    const std::unique_ptr<ngl::Obj> &getObstacle();
    void loadMatricesToShader(ngl::Transformation &_tx, const ngl::Mat4 &_globalMat,ngl::Camera *_cam )const;
    void draw(const std::string &_shaderName, const ngl::Mat4 &_globalMat, ngl::Camera *_cam)const;

private:
    std::unique_ptr<ngl::Obj> m_sphere;

};

#endif
