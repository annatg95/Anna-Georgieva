#ifndef FISH_H
#define FISH_H
#include <string>
#include <memory>
#include <cmath>
#include <limits>

#include <ngl/Camera.h>
#include <ngl/Obj.h>
#include <ngl/ShaderLib.h>
#include <ngl/Random.h>
#include <ngl/VAOPrimitives.h>
#include <ngl/Transformation.h>
#include <ngl/NGLStream.h>
#include <ngl/ShaderLib.h>
#include <ngl/Random.h>

/**
 * @file Fish.h
 *
 * @brief Fish class that loads the OBJ mesh with all the inital components.
 *
 * @author Jon Macey,Anna Georgieva
 *
 *  collision functions are taken from the Bounding Box demo available https://github.com/NCCA/Collisions
 */



#define PI 3.1415926535897932384626433832795
class Flock;
class Fish
{
friend class Flock;
public:

    /*  @brief fish user defined constructor  */
    /*  @params - filename, texturename, position, velocity */
    /*------------------------------------------------------*/
    Fish(const std::string& _fname,  const std::string& _texName, ngl::Vec3 _pos, ngl::Vec3 _velo);

    /*  @brief returns the reference to the fish */
    /*  @params --- */
    /*------------------------------------------------------*/
    const std::unique_ptr<ngl::Obj> & getFish();

    /*  @brief load matrices to the current shader */
    /*  @params - object transformation, mouse matrix, camera */
    /*------------------------------------------------------*/
    void loadMatricesToShader(ngl::Transformation &_tx, const ngl::Mat4 &_globalMat,ngl::Camera *_cam )const;

    /*  @brief draws the object */
    /*  @params - the name of the shader, mouse matrix, camera */
    /*------------------------------------------------------*/
    void draw(const std::string &_shaderName, const ngl::Mat4 &_globalMat, ngl::Camera *_cam)const;

    /*  @brief moves the object */
    /*  @params - minimum speed, maximum speed */
    /*------------------------------------------------------*/
    void move(double _minS, double _maxS);

    /*  @brief calculates the object orientation */
    /*  @params ---  */
    /*------------------------------------------------------*/
    void rotate();

    /*  @brief controls the visibility of the bounding box */
    /*  @params - boolean state  */
    /*------------------------------------------------------*/
    inline void setBB(bool _bool){m_showBBox=_bool;}

    /*  @brief controls the visibility of the bounding sphere */
    /*  @params - boolean state  */
    /*------------------------------------------------------*/
    inline void setBS(bool _bool){m_showBSphere=_bool;}

    /*  @brief draws the bounding sphere */
    /*  @params - mouse matrix, camera  */
    /*------------------------------------------------------*/
    void drawS(const ngl::Mat4 &_globalMat,  ngl::Camera *_cam )const;

    /*  @brief draws the bounding box around the object */
    /*  @params - mouse matrix, camera  */
    /*------------------------------------------------------*/
    void drawB(const ngl::Mat4 &_globalMat,  ngl::Camera *_cam )const;

    /*  @brief returns the current position */
    /*  @params ---  */
    /*------------------------------------------------------*/
    inline ngl::Vec3 getPos(){return m_pos;}

    /*  @brief returns the next position */
    /*  @params --- */
    /*------------------------------------------------------*/
    inline ngl::Vec3 getNextPos() const {return m_nextPos;}

    /*  @brief defines the velocity */
    /*  @params ---  */
    /*------------------------------------------------------*/
    inline void setVelo(ngl::Vec3 _velo){m_velo=_velo;}

    /*  @brief returns the velocity of the object position */
    /*  @params --- */
    /*------------------------------------------------------*/
    inline ngl::Vec3 getVelo(){return m_velo;}

    /*  @brief updates the velocity of the object */
    /*  @params - velocity  */
    /*------------------------------------------------------*/
    inline void updateVelo(ngl::Vec3 _v){m_velo+=_v;}

    /*  @brief stops updating the velocity of the object */
    /*  @params - velocity  */
    /*------------------------------------------------------*/
    inline void stopVelocity(ngl::Vec3 _v){m_velo-=_v;}

    /*  @brief defines a neighbour */
    /*  @params - boolean state  */
    /*------------------------------------------------------*/
    inline void setNeighbour(bool _bool){isNeighbour=_bool;}

    /*  @brief returns boolean whether the fish has neighbour or not */
    /*  @params ---  */
    /*------------------------------------------------------*/
    inline bool isItNeighbour() {return isNeighbour;}

    /*  @brief reverse the position of the object */
    /*  @params ---  */
    /*------------------------------------------------------*/
    inline void reverse(){m_velo=m_velo*-1.0;}

    /*  @brief sets hit if the object is hit or not */
    /*  @params ---  */
    /*------------------------------------------------------*/
    inline void setHit(){m_hit=true;}

    /*  @brief sets hit if the object is hit or not */
    /*  @params ---  */
    /*------------------------------------------------------*/
    inline void setNotHit(){m_hit=false;}

    /*  @brief returns boolean whether the fish is hit or not*/
    /*  @params ---  */
    /*------------------------------------------------------*/
    inline bool isHit()const {return m_hit;}

private:
    // the obj mesh that corresponds to one fish
    std::unique_ptr<ngl::Obj> m_mesh;

    //position, velocity, last position, next position, rotation
    ngl::Vec3 m_pos;
    ngl::Vec3 m_velo;
    ngl::Vec3 m_lastPos;
    ngl::Vec3 m_nextPos;
    ngl::Vec3 m_rot;

    //boolean states for the bounding sphere, bounding box
    bool m_showBSphere;
    bool m_showBBox;

    //boolean state for checking the neighbours and hit state
    GLfloat m_emitAngle=360.0;
    bool isNeighbour;
    bool m_hit;

    //orientation angles
    float m_yaw;//y-axis
    float m_pitch;//x-axis
};

#endif // FISH_H
