#ifndef FLOCK_H_
#define FLOCK_H_
#include <string>
#include <memory>
#include "Fish.h"
#include <ngl/Random.h>


/**
 * @file Flock.h
 *
 * @brief Flock class that loads many fish and controls the movement.
 *
 * @author Jon Macey,Anna Georgieva
 *
 *  collision functions are taken from the Bounding Box demo available https://github.com/NCCA/Collisions
 *  algorithms for the separation alignment and cohesion forces are taken from http://www.kfish.org/boids/pseudocode.html
 */

class Flock
{
public:
    /*  @brief flock user defined constructor  */
    /*  @params - filename, texturename, number of fish */
    /*------------------------------------------------------*/
    Flock(const std::string &_fname,const std::string& _tname,uint numFish);

    /*  @brief returns the number of fish  */
    /*  @params --- */
    /*------------------------------------------------------*/
    inline unsigned int getNumFish()const {return m_numFish;}

    /*  @brief draws all the fish  */
    /*  @params - name of the shader, mouse matrix, camera */
    /*------------------------------------------------------*/
    void draw(const std::string &_shaderName, const ngl::Mat4 &_globalMat, ngl::Camera *_cam)const;

    /*  @brief moves all the fish  */
    /*  @params --- */
    /*------------------------------------------------------*/
    void move();

    /*  @brief funciton calculates whether a fish is a neighbour or not  */
    /*  @params --- */
    /*------------------------------------------------------*/
    void currentDistanceBetween();

    /*  @brief adds a fish  */
    /*  @params --- */
    /*------------------------------------------------------*/
    void addFish();

    /*  @brief removes a fish  */
    /*  @params --- */
    /*------------------------------------------------------*/
    void removeFish();

    /*  @brief shows/hides the bounding box  */
    /*  @params boolean state */
    /*------------------------------------------------------*/
    void showHideBB(bool _bool);

    /*  @brief shows/hides the bounding sphere  */
    /*  @params boolean state */
    /*------------------------------------------------------*/
    void showHideBS(bool _bool);

    /*  @brief sets the separation force  */
    /*  @params passed force */
    /*------------------------------------------------------*/
    inline void setSF(double force_in) {sepForce=force_in;}

    /*  @brief sets the alignment force  */
    /*  @params passed force */
    /*------------------------------------------------------*/
    inline void setAF(double force_in) {aliForce=force_in;}

    /*  @brief sets the Cohesion force  */
    /*  @params passed force */
    /*------------------------------------------------------*/
    inline void setCF(double force_in) {cohForce=force_in;}

    /*  @brief sets the neighbours distance between fish  */
    /*  @params passed force */
    /*------------------------------------------------------*/
    inline void setNeighD(double _neighD) {m_neighD = _neighD;}

    /*  @brief sets the separation distance between fish  */
    /*  @params passed force */
    /*------------------------------------------------------*/
    inline void setSepD(double _sepD) {m_sepD = _sepD;}

    /*  @brief calculates the separation force  */
    /*  @params fish number*/
    /*------------------------------------------------------*/
    void separation(uint _fishN);

    /*  @brief calculates the alignment force  */
    /*  @params fish number*/
    /*------------------------------------------------------*/
    void alignment(uint _fishN);

    /*  @brief calculates the cohesion force  */
    /*  @params fish number*/
    /*------------------------------------------------------*/
    void cohesion(uint _fishN);

    /*  @brief calculates the cohesion avoidance  */
    /*  @params fish number*/
    /*------------------------------------------------------*/
    void collisionA(uint _fishN);

    /*  @brief calculates the new velocity based on the three forces  */
    /*  @params ---*/
    /*------------------------------------------------------*/
    ngl::Vec3 calculateVelocity();

    /*  @brief checks all the collisions  */
    /*  @params bounding box*/
    /*------------------------------------------------------*/
    void checkCollisions(const std::unique_ptr<ngl::BBox> &_box);

    /*  @brief checks the box collisions  */
    /*  @params bounding box*/
    /*------------------------------------------------------*/
    void BBoxCollision(const std::unique_ptr<ngl::BBox> &_box);

    /*  @brief checks the fish collisions  */
    /*  @params --- */
    /*------------------------------------------------------*/
    void checkFishCollisions();

    /*  @brief checks the fish with fish collisions  */
    /*  @params --- */
    /*------------------------------------------------------*/
    bool fishFishCollison(ngl::Vec3 _pos1, GLfloat _radius1, ngl::Vec3 _pos2, GLfloat _radius2 );

    /*  @brief returns the values of all the forces declared above  */
    /*  @params --- */
    /*------------------------------------------------------*/
    inline double getSF() {return sepForce;}
    inline double getAF() {return aliForce;}
    inline double getCF() {return cohForce;}
    inline double getAvoF() {return maxAvoForce;}
    inline double getMinS(){return m_minS;}
    inline double getMaxS(){return m_maxS;}
    inline double getNeighD() {return m_neighD;}
    inline double getSepD() {return m_sepD;}

private:
    //assigns all the forces to zero values
    double sepForce=0;
    double aliForce=0;
    double cohForce=0;
    double maxAvoForce=0;
    double m_neighD=0;
    double m_sepD=0;

    //assigns the maximum speed and the minimum speed
    float m_minS=1.5;
    float m_maxS=3.0;

    //vector of all the fish
    std::vector<std::unique_ptr<Fish>> m_fish;

    //number of fish
    unsigned int m_numFish;

    // the three main forces
    ngl::Vec3 m_separation,m_alignment,m_cohesion;
};


#endif
