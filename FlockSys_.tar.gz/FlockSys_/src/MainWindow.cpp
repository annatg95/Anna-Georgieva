#include "MainWindow.h"
#include "ui_MainWindow.h"
#include <QFileDialog>
#include <QFile>
#include <QMessageBox>

MainWindow::MainWindow(QWidget *parent) :QMainWindow(parent), m_ui(new Ui::MainWindow)
{
    m_ui->setupUi(this);

    std::string oname("models/Helix.obj");
    std::string tname("textures/helix_base.tif");

    m_gl=new NGLScene(this,oname,tname, 20);
    m_ui->s_mainWindowGridLayout->addWidget(m_gl,0,0,2,1);

    //buttons for all the forces
    connect(m_ui->m_aliForce,SIGNAL(valueChanged(double)),m_gl,SLOT(setAliForce(double)));
    connect(m_ui->m_cohForce,SIGNAL(valueChanged(double)),m_gl,SLOT(setCohForce(double)));
    connect(m_ui->m_sepForce,SIGNAL(valueChanged(double)),m_gl,SLOT(setSepForce(double)));
    m_ui->m_aliForce->setRange(0,30);
    m_ui->m_cohForce->setRange(0,30);
    m_ui->m_sepForce->setRange(0,30);

    //checkbos for all the options
    connect(m_ui->m_showBB2,SIGNAL(stateChanged(int)),m_gl,SLOT(showHideBB(int)));
    connect(m_ui->m_showBS2,SIGNAL(stateChanged(int)),m_gl,SLOT(showHideBS(int)));
    connect(m_ui->m_RP,SIGNAL(stateChanged(int)),m_gl,SLOT(setAnim(int)));

    //buttons for adding and removing fish
    connect(m_ui->m_addFish,SIGNAL(clicked()),m_gl,SLOT(addFish()));
    connect(m_ui->m_rmFish,SIGNAL(clicked()),m_gl,SLOT(removeFish()));

    //setting the separation distance and the neighbourhood distance
    connect(m_ui->m_separation,SIGNAL(valueChanged(double)),m_gl,SLOT(setSepD(double)));
    connect(m_ui->m_neighbour,SIGNAL(valueChanged(double)),m_gl,SLOT(setNeighD(double)));
    m_ui->m_separation->setRange(0,30);
    m_ui->m_neighbour->setRange(0,30);

}

MainWindow::~MainWindow()
{
    delete m_ui;
}

//when the start button is clicked
void MainWindow::on_m_simulate_clicked()
{
    //this function DOES read from a file AND SHOWS the initial values as a example file
    //the user can create his own following this example!
    //--------------------------------------------------------------------------------------
    std::cout<<"start!"<<std::endl;

    //loading the address of the file
    QFile file("/home/i7626222/CA1/FlockSys_/file.txt");

    //copying the address of the file for display funcitons only
    QFile InitCopyFile("/home/i7626222/CA1/FlockSys_/file.txt");

    //initialize all the possible entries as structs
    textInput InitAliF,InitCohF,InitSepF,InitNeighbourD,InitSeparationD;

    //check whether the text file is open
    if((!file.open(QIODevice::ReadOnly))||(!InitCopyFile.open(QIODevice::ReadOnly)))
    {
        QMessageBox::information(0,"not found",file.errorString());
        QMessageBox::information(0,"not found",InitCopyFile.errorString());
    }
    else
    {
        //declare a streams
        QTextStream in2(&file);
        QTextStream inDisplay(&InitCopyFile);
        {
            //read values for every struct declared above
            textInputRead(&InitAliF,in2);
            textInputRead(&InitCohF,in2);
            textInputRead(&InitSepF,in2);
            textInputRead(&InitNeighbourD,in2);
            textInputRead(&InitSeparationD,in2);

            //set the corresponding values
            m_gl->setAliForce(InitAliF.value);
            m_gl->setCohForce(InitCohF.value);
            m_gl->setSepForce(InitSepF.value);
            m_gl->setNeighD(InitNeighbourD.value);
            m_gl->setSepD(InitSeparationD.value);

            //display the corresponding values
            m_ui->m_aliForce->setValue(InitAliF.value);
            m_ui->m_cohForce->setValue(InitCohF.value);
            m_ui->m_sepForce->setValue(InitSepF.value);
            m_ui->m_neighbour->setValue(InitNeighbourD.value);
            m_ui->m_separation->setValue(InitSeparationD.value);
        }
        //display the text from the copied text file
        m_ui->textBrowser->setText(inDisplay.readAll());
    }
    //close the file
    file.close();

}


void MainWindow::on_m_stop_clicked()
{
    //assign all the values to 0 state
    std::cout<<"stop!"<<std::endl;
    m_gl->setAliForce(0);
    m_gl->setCohForce(0);
    m_gl->setSepForce(0);
    m_gl->setNeighD(0);
    m_gl->setSepD(0);

    //display the correspodning values
    m_ui->m_aliForce->setValue(0);
    m_ui->m_cohForce->setValue(0);
    m_ui->m_sepForce->setValue(0);
    m_ui->m_neighbour->setValue(0);
    m_ui->m_separation->setValue(0);
}


void MainWindow::textInputRead(textInput *_a, QTextStream &_in)
{
    //read the text from the file and print the values
    _in>>_a->id>>_a->letter>>_a->value;
    std::cout<<"id : "<<_a->id<<std::endl;
    std::cout<<"force : "<<_a->letter.toStdString()<<std::endl;
    std::cout<<"value : "<<_a->value<<std::endl;

}

void MainWindow::on_m_yourTxt_clicked()
{
    //this function DOES read from a file AND SHOWS the values that the user loaded from a file
    //------------------------------------------------------

    /**
     * the same function like on_m_simulate_clicked() but it is loading it from a text file
     */

    filename = QFileDialog::getOpenFileName(this,"Select txt file",".","Text files (*.txt);; All files (*.*)");
    QFile yourFile(filename);
    QFile copyFile(filename);

    textInput aliF,cohF,sepF,neighbourD,separationD;

    if((!yourFile.open(QIODevice::ReadOnly)) || (!copyFile.open(QIODevice::ReadOnly)))
    {
        QMessageBox::information(0,"info",yourFile.errorString());
        QMessageBox::information(0,"info",copyFile.errorString());
    }
    else
    {
        QTextStream in(&yourFile);
        QTextStream inDisplay(&copyFile);
        {
            textInputRead(&aliF,in);
            textInputRead(&cohF,in);
            textInputRead(&sepF,in);
            textInputRead(&neighbourD,in);
            textInputRead(&separationD,in);

            m_gl->setAliForce(aliF.value);
            m_gl->setCohForce(cohF.value);
            m_gl->setSepForce(sepF.value);
            m_gl->setNeighD(neighbourD.value);
            m_gl->setSepD(separationD.value);

            m_ui->m_aliForce->setValue(aliF.value);
            m_ui->m_cohForce->setValue(cohF.value);
            m_ui->m_sepForce->setValue(sepF.value);
            m_ui->m_neighbour->setValue(neighbourD.value);
            m_ui->m_separation->setValue(separationD.value);
        }
        m_ui->textBrowser->setText(inDisplay.readAll());
    }
    yourFile.close();

}
