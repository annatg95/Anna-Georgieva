#include <QMouseEvent>
#include <QGuiApplication>
#include <QFont>
#include "NGLScene.h"
#include <iostream>
#include <ngl/Vec3.h>
#include <ngl/Light.h>
#include <ngl/NGLInit.h>
#include <ngl/Random.h>
#include <ngl/Material.h>
#include <ngl/Transformation.h>
#include <ngl/NGLStream.h>
#include <ngl/VAOPrimitives.h>

const static int s_extents=20;

//NGLSCENE taken from  QtNGL Demo available https://github.com/NCCA/QtNGL
NGLScene::NGLScene( QWidget *_parent, const std::string &_oname, const std::string &_tname, int n_fish ) : QOpenGLWidget( _parent )
{
    //initializing the boolean to true
    m_animate=true;

    //initializing the number of fish
    m_numFish=n_fish;

    //initializing the filename and the texturename
    m_objFileName=_oname;
    m_textureFileName=_tname;

    //initializing the rays lengths
    m_rayStart.set(0,0,0);
    m_rayEnd.set(0,20,0);
    m_rayStart2.set(0,0,0);
    m_rayEnd2.set(20,0,0);
    m_rayStart3.set(0,0,0);
    m_rayEnd3.set(0,0,20);

}

NGLScene::~NGLScene()
{
    std::cout<<"Shutting down NGL, removing VAO's and Shaders\n";
}

void NGLScene::resizeGL( int _w, int _h )
{
    m_cam.setShape( 45.0f, static_cast<float>( _w ) / _h, 0.05f, 350.0f );
    m_win.width  = static_cast<int>( _w * devicePixelRatio() );
    m_win.height = static_cast<int>( _h * devicePixelRatio() );
}

void NGLScene::initializeGL()
{
    ngl::NGLInit::instance();

    glClearColor(0.4f, 0.4f, 0.4f, 1.0f);			   // Grey Background
    glEnable(GL_DEPTH_TEST);
    glEnable(GL_MULTISAMPLE);

    ngl::Vec3 from(100,200,450);
    //from.operator /=(2);
    ngl::Vec3 to(0,0,0);
    ngl::Vec3 up(0,1,0);
    m_cam.set(from,to,up);
    m_cam.setShape(45.0f,720.0f/576.0f,0.05f,350.0f);

    m_bbox.reset( new ngl::BBox(ngl::Vec3::zero(),300.0f,300.0f,300.0f));
    m_bbox->setDrawMode(GL_LINE);

    ngl::ShaderLib *shader=ngl::ShaderLib::instance();
    shader->createShaderProgram("TextureShader");
    shader->attachShader("TextureVertex",ngl::ShaderType::VERTEX);
    shader->attachShader("TextureFragment",ngl::ShaderType::FRAGMENT);
    shader->loadShaderSource("TextureVertex","shaders/TextureVertex.glsl");
    shader->loadShaderSource("TextureFragment","shaders/TextureFragment.glsl");
    shader->compileShader("TextureVertex");
    shader->compileShader("TextureFragment");
    shader->attachShaderToProgram("TextureShader","TextureVertex");
    shader->attachShaderToProgram("TextureShader","TextureFragment");
    shader->linkProgramObject("TextureShader");
    (*shader)["TextureShader"]->use();
    (*shader)["nglColourShader"]->use();
    shader->setShaderParam4f("Colour",1.0,1.0,1.0,1.0);
    (*shader)["nglColourShader"]->use();

    //resetting the flock pointer
    m_flock.reset(new Flock(m_objFileName,m_textureFileName,m_numFish));

    std::string sname="models/sphere.obj";
    std::string tsname="textures/sphere.tif";
    m_obstacle.reset(new Obstacle(sname,tsname));

    ngl::VAOPrimitives *prim=ngl::VAOPrimitives::instance();
    prim->createSphere("sphere",1.0,20);
    glViewport(0,0,width(),height());

    //text rendered on screen
    m_text.reset(new ngl::Text(QFont("Arial",16)));
    m_text->setScreenSize(width(),height());
    m_text->setColour(1,1,1);
    m_fishUpdateTimer=startTimer(30);
}

void NGLScene::loadMatricesToColourShader()
{
    ngl::ShaderLib *shader=ngl::ShaderLib::instance();
    (*shader)["nglColourShader"]->use();
    ngl::Mat4 MV;
    ngl::Mat4 MVP;
    MV= m_mouseGlobalTX*m_cam.getViewMatrix() ;
    MVP=MV*m_cam.getProjectionMatrix();
    shader->setShaderParamFromMat4("MVP",MVP);
}

void NGLScene::loadMatricesToShader()
{
    ngl::ShaderLib *shader=ngl::ShaderLib::instance();
    ngl::Mat4 MVP=m_transform.getMatrix()*m_mouseGlobalTX*m_cam.getVPMatrix();
    shader->setShaderParamFromMat4("MVP",MVP);
}


void NGLScene::paintGL()
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glViewport(0,0,m_win.width,m_win.height);

    ngl::Mat4 rotX;
    ngl::Mat4 rotY;
    rotX.rotateX(m_win.spinXFace);
    rotY.rotateY(m_win.spinYFace);

    m_mouseGlobalTX=rotY*rotX;
    m_mouseGlobalTX.m_m[3][0] = m_modelPos.m_x;
    m_mouseGlobalTX.m_m[3][1] = m_modelPos.m_y;
    m_mouseGlobalTX.m_m[3][2] = m_modelPos.m_z;

    resetRay();
    //use the texture shader and draw the fish
    ngl::ShaderLib *shader=ngl::ShaderLib::instance();
    (*shader)["TextureShader"]->use();
    m_flock->draw("TextureShader", m_mouseGlobalTX,&m_cam);

//  (*shader)["TextureShader"]->use();
//  m_obstacle->draw("TextureShader",m_mouseGlobalTX,&m_cam);

    //use the colour shader and draw
    (*shader)["nglColourShader"]->use();
    loadMatricesToColourShader();
    shader->setShaderParam4f("Colour",1,1,1,1);
    m_bbox->draw();

    //render the text
    QString text;
    text.sprintf("number of fish %d",m_flock->getNumFish());
    m_text->setColour(1,1,1);
    m_text->renderText(10,5,QString("Flocking System"));
    m_text->renderText(10,25,text);

    // test code
//    static long time = 0;
//    if (!(time % 4))
//    {
//        std::cout<< time <<" -> kill fish" <<std::endl;
//        m_flock->removeFish();
//    }
//    time++;
}

void NGLScene::updateScene()
{
    //moves all the fish
    m_flock->move();
    //checks the bounding box collisions
    m_flock->checkCollisions(m_bbox);

}

void NGLScene::timerEvent(QTimerEvent *_event)
{
    //updates the timer and checks for the animation state
    if(_event->timerId() == m_fishUpdateTimer)
    {
        if (m_animate !=true)
        {
            return;
        }
    }
    updateScene();
    update();
}

// Rays exmaple taken from the Collisions demo available https://github.com/NCCA/Collisions
void NGLScene::resetRay( )
{
    ngl::ShaderLib *shader=ngl::ShaderLib::instance();

    m_transform.reset();
    {
        shader->use("nglColourShader");
        shader->setRegisteredUniform4f("Colour",0,0,1,1);
        std::unique_ptr<ngl::AbstractVAO> vao( ngl::VAOFactory::createVAO("simpleVAO",GL_LINES));

        vao->bind();
        ngl::Vec3 points[6];
        points[0]=m_rayStart;
        points[1]=m_rayEnd;
        points[2]=m_rayStart2;
        points[3]=m_rayEnd2;
        points[4]=m_rayStart3;
        points[5]=m_rayEnd3;

        vao->setData(ngl::SimpleVAO::VertexData(6*sizeof(ngl::Vec3),points[0].m_x));
        vao->setVertexAttributePointer(0,3,GL_FLOAT,sizeof(ngl::Vec3),0);
        vao->setNumIndices(6);
        loadMatricesToColourShader();
        vao->draw();
        vao->removeVAO();
    }
}



