#include <QApplication>
#include "MainWindow.h"

/**
 * @file MainWindow.h
 *
 * @brief MainWindow class for the GUI.
 *
 * @author Jon Macey, Anna Georgieva
 *
 * code taken from  QtNGL Demo available https://github.com/NCCA/QtNGL
 *
 */
int main(int argc, char **argv)
{
  QSurfaceFormat format;
  format.setSamples(4);
  #if defined( DARWIN)
    format.setMajorVersion(4);
    format.setMinorVersion(2);
  #else
    format.setMajorVersion(4);
    format.setMinorVersion(3);
  #endif
  format.setProfile(QSurfaceFormat::CoreProfile);
  format.setDepthBufferSize(24);

  QSurfaceFormat::setDefaultFormat(format);
  QApplication a(argc, argv);
  
  MainWindow w;
  w.show();

  return a.exec();
}
