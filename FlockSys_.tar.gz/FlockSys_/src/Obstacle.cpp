#include "Obstacle.h"

/*
 * in progress - not finished
 */

Obstacle::Obstacle(const std::string &_fname, const std::string &_tname)
{
    m_sphere.reset(new ngl::Obj(_fname,_tname));
    m_sphere->createVAO();
    m_sphere->calcBoundingSphere();
}

const std::unique_ptr<ngl::Obj> &Obstacle::getObstacle()
{
    return (m_sphere);
}

void Obstacle::loadMatricesToShader(ngl::Transformation &_tx, const ngl::Mat4 &_globalMat,ngl::Camera *_cam )const
{
    ngl::ShaderLib *shader=ngl::ShaderLib::instance();
    ngl::Mat4 MV;
    ngl::Mat4 MVP;
    MV=_tx.getMatrix()*_globalMat*_cam->getViewMatrix() ;
    MVP=MV*_cam->getProjectionMatrix();
    shader->setShaderParamFromMat4("MVP",MVP);
}

void Obstacle::draw(const std::string &_shaderName, const ngl::Mat4 &_globalMat, ngl::Camera *_cam)const
{
    ngl::Transformation t;
    t.setPosition(0,20,20);
    t.setScale(5,5,5);
    loadMatricesToShader(t,_globalMat,_cam);
    m_sphere->draw();
}
