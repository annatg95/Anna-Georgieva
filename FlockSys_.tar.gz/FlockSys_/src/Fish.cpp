#include "Fish.h"

Fish::Fish(const std::string &_fname, const std::string &_texName,ngl::Vec3 _pos, ngl::Vec3 _velo)
{
    //reseting the obj mesh
    m_mesh.reset(  new ngl::Obj(_fname,_texName));

    //creating vertex array object
    m_mesh->createVAO();

    //calculate the bounding sphere
    m_mesh->calcBoundingSphere();

    //emitter effect taken from the https://github.com/NCCA/ParticleFactory
    ngl::Random *rng=ngl::Random::instance();
    GLfloat theta=ngl::radians(rng->randomNumber(m_emitAngle));
    GLfloat phi=ngl::radians(rng->randomNumber(m_emitAngle));

    m_velo.m_x=sin(theta)*cos(phi);
    m_velo.m_y=sin(theta)*sin(phi);
    m_velo.m_z=cos(theta);
    m_velo.normalize();

    m_pos=_pos;
    m_showBSphere=false;
    m_showBBox=false;
}

const std::unique_ptr<ngl::Obj> &Fish::getFish()
{
    return (m_mesh);
}

void Fish::loadMatricesToShader(ngl::Transformation &_tx, const ngl::Mat4 &_globalMat,ngl::Camera *_cam )const
{
    ngl::ShaderLib *shader=ngl::ShaderLib::instance();
    ngl::Mat4 MV;
    ngl::Mat4 MVP;
    MV=_tx.getMatrix()*_globalMat*_cam->getViewMatrix() ;
    MVP=MV*_cam->getProjectionMatrix();
    shader->setShaderParamFromMat4("MVP",MVP);
}

void Fish::draw(const std::string &_shaderName, const ngl::Mat4 &_globalMat, ngl::Camera *_cam)const
{
    //loading the shader
    ngl::ShaderLib *shader=ngl::ShaderLib::instance();
    //according to the name
    shader->use(_shaderName);

    //setting the rotation and the position
    ngl::Transformation t;
    t.setRotation(m_rot);
    t.setPosition(m_pos);

    //making the fish smaller
    t.setScale(0.8,0.8,0.8);

    loadMatricesToShader(t,_globalMat,_cam);
    m_mesh->draw();

    //drawing bounding box and bounding sphere if the boolean is true
    (*shader)["nglColourShader"]->use();
    if(m_showBBox==true)
    {
        drawB(_globalMat,_cam);
    }

    //drawing bounding box and bounding sphere if the boolean is true
    if(m_showBSphere==true)
    {
       drawS(_globalMat,_cam);
    }
}


void Fish::move(double _minS, double _maxS)
{
    //move the fish and match their veloxity with the miminum and maximum speed
    m_lastPos=m_pos;

    //algorithm taken from http://www.kfish.org/boids/pseudocode.html
    //LIMITING THE SPEED
    if (m_velo.length() > _maxS)
    {
        m_velo.normalize();
        m_velo=m_velo*_maxS;
    }
    else if (m_velo.length() < _minS)
    {
        m_velo.normalize();
        m_velo=m_velo*_minS;
    }
    m_pos+=(m_velo);
    m_nextPos=m_pos+(m_velo);
}


void Fish::rotate()
{
    //calculates the orientation of the object
    //algorithm taken from http://stackoverflow.com/questions/18184848/calculate-pitch-and-yaw-between-two-unknown-points
    m_yaw = atan2(m_velo.m_x,m_velo.m_z)*180/PI+180;//y
    m_pitch = atan2(m_velo.m_y,sqrt(m_velo.m_x*m_velo.m_x+m_velo.m_z*m_velo.m_z))*180/PI;//x
    m_rot.set(m_pitch,m_yaw,0);
}

void Fish::drawB(const ngl::Mat4 &_globalMat,  ngl::Camera *_cam )const
{
    //draw the bounding box of the obj taken from the obj demo
    ngl::ShaderLib *shader=ngl::ShaderLib::instance();
    (*shader)["nglColourShader"]->use();
    shader->setShaderParam4f("Colour",0,0,1,1);

    ngl::Transformation t;

    if((m_showBBox==true))
    {
        t.setRotation(m_rot);
        t.setPosition(m_pos);
        loadMatricesToShader(t,_globalMat,_cam);
        m_mesh->drawBBox();
    }

}

void Fish::drawS( const ngl::Mat4 &_globalMat,  ngl::Camera *_cam )const
{
    //draw bounding sphere of the obj taken from the obj demo
    ngl::ShaderLib *shader=ngl::ShaderLib::instance();
    if((m_showBSphere==true))
    {
        ngl::VAOPrimitives *prim=ngl::VAOPrimitives::instance();
        shader->setShaderParam4f("Colour",1,1,1,1);

        ngl::Transformation t;
        glPolygonMode(GL_FRONT_AND_BACK,GL_LINE);
        t.setPosition(m_mesh->getSphereCenter());
        t.setScale(m_mesh->getSphereRadius(),m_mesh->getSphereRadius(),m_mesh->getSphereRadius());
        t.setPosition(m_pos.m_x,m_pos.m_y,m_pos.m_z);

        loadMatricesToShader(t,_globalMat,_cam);
        prim->draw("sphere");
        glPolygonMode(GL_FRONT_AND_BACK,GL_FILL);
    }
}


