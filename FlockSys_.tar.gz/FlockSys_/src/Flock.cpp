#include "Flock.h"

const static int s_extents=20;

Flock::Flock(const std::string &_fname,const std::string& _tname,uint numFish)
{    
    m_numFish=numFish;

    //generating random values and assigning it to the velocity
    ngl::Vec3 velo,rot;
    ngl::Random *rng=ngl::Random::instance();

    m_numFish=numFish;
    for(uint i=0; i<m_numFish; ++i)
    {
       velo=rng->randomPositiveNumber(1);
       //assigning a zero vector to the rotation
       rot=ngl::Vec3::zero();
       m_fish.push_back((std::unique_ptr<Fish>(new Fish(_fname,_tname,rng->getRandomPoint(s_extents,s_extents,s_extents),velo))));
    }

    static uint counter=0;
    for(counter=0; counter<m_fish.size();++counter)
    {
        //resetting the m_fish unique pointer
       m_fish[counter].reset( new Fish(_fname,_tname,rng->getRandomPoint(s_extents,s_extents,s_extents),velo));
    }

}

void Flock::draw(const std::string &_shaderName, const ngl::Mat4 &_globalMat, ngl::Camera *_cam)const
{
  for(uint i=0; i<m_fish.size();i++)
  {
      //drawing all the fish that the std::vector contains
      m_fish[i]->draw("TextureShader", _globalMat,_cam);
  }
}

void Flock::addFish()
{
    //adding a fish
    std::string oname("models/Helix.obj");
    std::string tname("textures/helix_base.tif");

    m_fish.resize(m_numFish);
    ngl::Random *rng=ngl::Random::instance();
    ngl::Vec3 dir,rot;
    dir=rng->randomPositiveNumber(1);
    rot=rng->randomPositiveNumber(1);
    m_fish.push_back((std::unique_ptr<Fish>(new Fish(oname,tname,rng->getRandomPoint(s_extents,s_extents,s_extents),dir))));
    ++m_numFish;
}

void Flock::removeFish()
{
    //remove fish but keep 2
    if(m_numFish>2)
    {
        m_fish.pop_back();
        m_numFish--;
    }
    else
    {
        std::cout<<"keep at least 2 fish for the forces to be applied"<<std::endl;
    }

}

void Flock::showHideBB(bool _bool)
{
    for(uint i=0; i<m_numFish; ++i)
    {
        //drawing bbox if the boolean is true/false
        m_fish[i]->setBB(_bool);
    }
}

void Flock::showHideBS(bool _bool)
{
    for(uint i=0; i<m_numFish; ++i)
    {
        //drawing bsphere if the boolean is true/false
        m_fish[i]->setBS(_bool);
    }
}


void Flock::move()
{
    for(uint i=0;i<m_fish.size(); ++i)
    {
        //for every fish rotate it accordingly to the direction that it is going to
        m_fish[i]->rotate();
        //move it with the according speed
        m_fish[i]->move(m_minS, m_maxS);

        //apply the forces
        cohesion(i);
        alignment(i);
        separation(i);

        //if there is a obstacle calculate another velocity called collision Avoidance
        /* in progress- not finished*/
        collisionA(i);

        //update the new velocity with all the forces applied
        m_fish[i]->updateVelo(calculateVelocity());
    }
}

void Flock::checkCollisions(const std::unique_ptr<ngl::BBox> &_box)
{
    BBoxCollision(_box);

// test functions

//  checkFishCollisions();
//  currentDistanceBetween();
}

//bbox function taken from the Bounding Box demo https://github.com/NCCA/Collisions
void Flock::BBoxCollision(const std::unique_ptr<ngl::BBox> &_box)
{
    float ext[6];
    ext[0]=ext[1]=(_box->height()/2.0f);
    ext[2]=ext[3]=(_box->width()/2.0f);
    ext[4]=ext[5]=(_box->depth()/2.0f);

    ngl::Vec3 p;
    GLfloat D;
    for(auto &f : m_fish)
    {
      p=f->getPos();
      p+=(f->getVelo()); //stops the shaking
      for(int i=0; i<6; ++i)
      {
        D=_box->getNormalArray()[i].dot(p);
        D+=f->getFish()->getSphereRadius();
        if(D >=ext[i])
        {
          GLfloat x= 2*( f->getVelo().dot((_box->getNormalArray()[i])));
          ngl::Vec3 d =_box->getNormalArray()[i]*x;
          f->setVelo(f->getVelo()-d);
          f->setHit();
        }
       }
      }
}


//funcitons that checks for neighbours
/* in progress- not finished*/
//the idea behind was to calculate the fish neighbours
//push_back in a std::vector<Fish>m_neighbours if they are neighbours
//pop_back when they arent neighbours
//so that you can apply the cohesion alignment and separation easier
void Flock::currentDistanceBetween()
{
    unsigned int size=m_fish.size();
    ngl::Vec3 temp;
    ngl::Vec3 neighbourDistance=ngl::Vec3(m_neighD,m_neighD,m_neighD);
    GLfloat magnitude=neighbourDistance.length();


    for(uint ToCheck=0; ToCheck<size; ++ToCheck)
    {
        for(uint Current=0; Current<size; ++Current)
        {
            if(ToCheck == Current)
            {
                continue;
            }
            else
            {
                temp=m_fish[Current]->getPos()-m_fish[ToCheck]->getPos();
                GLfloat tempMagnitude=temp.length();
                if(tempMagnitude<magnitude)
                {
                    m_fish[Current]->setNeighbour(true);
                    std::cout<<"Neighbour"<<std::endl;


                }
                else
                {
                    m_fish[Current]->setNeighbour(false);
                    std::cout<<"Not Neighbour"<<std::endl;

                }
            }
        }
    }

}


//bbox function taken from the Bounding Box demo https://github.com/NCCA/Collisions
bool Flock::fishFishCollison( ngl::Vec3 _pos1, GLfloat _radius1, ngl::Vec3 _pos2, GLfloat _radius2 )
{
    ngl::Vec3 relPos;
    GLfloat dist;
    GLfloat minDist;
    GLfloat len;
    relPos =_pos1-_pos2;
    len=relPos.length();
    dist=len*len;
    minDist =_radius1+_radius2;

    if(dist <=(minDist * minDist))
    {
        return true;
    }
    else
    {
        return false;
    }
}


//bbox function taken from the Bounding Box demo https://github.com/NCCA/Collisions
void  Flock::checkFishCollisions()
{
  bool collide;

  unsigned int size=m_fish.size();

    for(unsigned int ToCheck=0; ToCheck<size; ++ToCheck)
    {
        for(unsigned int Current=0; Current<size; ++Current)
        {

            if(ToCheck == Current)  continue;

      else
      {

        collide =fishFishCollison(m_fish[Current]->getPos(),m_fish[Current]->getFish()->getSphereRadius(),
                                  m_fish[ToCheck]->getPos(),m_fish[ToCheck]->getFish()->getSphereRadius());
        if(collide== true)
        {
          //m_fish[Current]->reverse();
        //  std::cout<<"HIT"<<std::endl;
          m_fish[Current]->setHit();
        }
        else
        {
          //  std::cout<<"Not HIT"<<std::endl;
        }
      }
    }
  }
}

//algorithm taken from http://www.kfish.org/boids/pseudocode.html
void Flock::alignment(uint _fishN)
{
    m_alignment=ngl::Vec3::zero();
    ngl::Vec3 distance = ngl::Vec3::zero();
    uint counter =0;
    uint neighbourhood = 1; // you already have one fish that checks if it is not itself

    //loop through all the fish
    for (counter=0;counter<m_fish.size();++counter)
    {
        if (counter!=_fishN)  //check if the fish is not itself
        {
            //calculate the distance between the current fish and the other fish
            distance = m_fish[_fishN]->getPos() - m_fish[counter]->getPos();

            //if the distance is less than the neighbourhood distance set by the user in the ui
            if (distance.length() < m_neighD)
            {
                //sum the velocities of all the fish
                m_alignment+=( m_fish[counter]->getVelo());
                //increase the neighbourhood
                ++neighbourhood;
            }
        }
    }
    //average the force
    m_alignment/=(neighbourhood);
    //subtract one third to the boid's current velocity.
    m_alignment-=(m_fish[_fishN]->getVelo()/3);
}

//algorithm taken from http://www.kfish.org/boids/pseudocode.html
void Flock::cohesion(uint _fishN)
{
    m_cohesion = ngl::Vec3::zero();
    ngl::Vec3 distance = ngl::Vec3::zero();
    uint counter =0;
    uint neighbourhood=1;   // you already have one fish that checks if it is not itself

    //loop through all the fish
    for (counter=0;counter<m_fish.size();++counter)
    {
        if (counter!=_fishN) //check if the fish is not itself
        {
            //calculate the distance between the current fish and the other fish
            distance = m_fish[_fishN]->getPos() - m_fish[counter]->getPos();
            //if the distance is less than the neighbourhood distance set by the user in the ui
            if (distance.length() < m_neighD)
            {
                //sum the positions of all the fish
                m_cohesion +=( m_fish[counter]->getPos());
                //increase the neighbourhood
                ++neighbourhood;
            }
        }
    }
    //average the positions to find the average point
    m_cohesion/=(neighbourhood);
    //move the fish one percent towards the center
    m_cohesion=(m_cohesion-m_fish[_fishN]->getPos())/100;
}

//algorithm taken from http://www.kfish.org/boids/pseudocode.html
void Flock::separation (uint _fishN)
{
    m_separation=ngl::Vec3::zero();
    ngl::Vec3 distance =ngl::Vec3::zero() ;
    uint counter =0;

    //iterate through all the fish
    for (counter=0;counter<m_fish.size();++counter)
    {
        if (counter!=_fishN) //check if the fish is not itself
        {
             //calculate the distance between the current fish and the other fish
             distance = m_fish[_fishN]->getPos() - m_fish[counter]->getPos();

             //if the distance is less than the separate distance set by the user in the ui
             if (distance.length()<m_sepD)
             {
                //subtracting the displacement of each boid which is near by
                m_separation-=(m_fish[_fishN]->getPos()- m_fish[counter]->getPos());
             }

        }
    }
}

//collision avoidance algorithm - https://gamedevelopment.tutsplus.com/tutorials/understanding-steering-behaviors-collision-avoidance--gamedev-7777
/* in progress- not finished*/
// I wanted to implement the object avoidance algorithm, but i didn't have time to finish it
void Flock::collisionA(uint _fishN)
{
    ngl::Vec3 maxSeeAhead=ngl::Vec3(5,5,5);
    uint counter=0;
    for(counter=0; counter<m_fish.size();++counter)
    {
        if(counter!=_fishN)
        {
            ngl::Vec3 veloNorm=m_fish[_fishN]->getVelo();
            veloNorm.normalize();
            ngl::Vec3 halfMaxAhead=ngl::Vec3(maxSeeAhead.m_x*0.5, maxSeeAhead.m_y*0.5, maxSeeAhead.m_z*0.5);

            ngl::Vec3 ahead=m_fish[_fishN]->getPos();
            ahead+=(veloNorm);
            ahead*(maxSeeAhead);
            ngl::Vec3 ahead2=m_fish[_fishN]->getPos();
            ahead2+=(veloNorm);
            ahead2*(halfMaxAhead);

        }
   }
}


//calculates the new velocity
ngl::Vec3 Flock::calculateVelocity()
{
    ngl::Vec3 _newVelo=ngl::Vec3::zero();

    //adding the forces and all the vectors together
    _newVelo = ((-1 * (sepForce/100))*m_separation)+ ((cohForce/100) * m_cohesion) + ((aliForce/100) * m_alignment);

    //limit the new velocity
    if (_newVelo.length() > m_minS)
    {
        _newVelo.normalize();
        _newVelo*(m_minS);
    }


    return _newVelo;
}

