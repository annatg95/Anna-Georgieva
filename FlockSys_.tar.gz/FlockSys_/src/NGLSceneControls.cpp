#include "NGLScene.h"
#include <QMouseEvent>

//NGLSCENE mouse events taken from  QtNGL Demo available https://github.com/NCCA/QtNGL
//----------------------------------------------------------------------------------------------------------------------
void NGLScene::mouseMoveEvent( QMouseEvent* _event )
{
  if ( m_win.rotate && _event->buttons() == Qt::LeftButton )
  {
    int diffx = _event->x() - m_win.origX;
    int diffy = _event->y() - m_win.origY;
    m_win.spinXFace += static_cast<int>( 0.5f * diffy );
    m_win.spinYFace += static_cast<int>( 0.5f * diffx );
    m_win.origX = _event->x();
    m_win.origY = _event->y();
    update();
  }
  else if ( m_win.translate && _event->buttons() == Qt::RightButton )
  {
    int diffX      = static_cast<int>( _event->x() - m_win.origXPos );
    int diffY      = static_cast<int>( _event->y() - m_win.origYPos );
    m_win.origXPos = _event->x();
    m_win.origYPos = _event->y();
    m_modelPos.m_x += INCREMENT * diffX;
    m_modelPos.m_y -= INCREMENT * diffY;
    update();
  }
}


//----------------------------------------------------------------------------------------------------------------------
void NGLScene::mousePressEvent( QMouseEvent* _event )
{
  if ( _event->button() == Qt::LeftButton )
  {
        m_win.origX  = _event->x();
        m_win.origY  = _event->y();
        m_win.rotate = true;
  }
  else if ( _event->button() == Qt::RightButton )
  {
        m_win.origXPos  = _event->x();
        m_win.origYPos  = _event->y();
        m_win.translate = true;
  }
  if (_event->button()== Qt::MiddleButton)
  {
      m_win.origXPos  = _event->x();
      m_win.origYPos  = _event->y();

      std::cout<<"x:"<< m_win.origXPos<<"   y:"<<m_win.origYPos<<std::endl;
  }
}


void NGLScene::mouseReleaseEvent( QMouseEvent* _event )
{
  if ( _event->button() == Qt::LeftButton )
  {
    m_win.rotate = false;
  }
  if ( _event->button() == Qt::RightButton )
  {
    m_win.translate = false;
  }
}


void NGLScene::wheelEvent( QWheelEvent* _event )
{
  if ( _event->delta() > 0 )
  {
    m_modelPos.m_z += ZOOM;
  }
  else if ( _event->delta() < 0 )
  {
    m_modelPos.m_z -= ZOOM;
  }
  update();
}
