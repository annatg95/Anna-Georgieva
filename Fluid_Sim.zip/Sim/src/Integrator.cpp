#include "Integrator.h"

#define SQR(x)		(x*x)


//ctor
Integrator::Integrator()
{
  m_deltaTime = 0.009f;
  //m_deltaTime = 0.003f;
  //m_deltaTime = 0.01f;
}

//velocity correction approximation introduced by Monaghan
void Integrator::velocityCorrectionXSPH(Particle *&particle_in, const GLfloat h_in, const GLfloat epsilon_in)
{
   //vector that stores the correction value
  ngl::Vec3 _correction;

  //for each neighbour in the neighbourhood
  BOOST_FOREACH(Particle *_n, particle_in->getNeighborList())
  {
      //position difference
    ngl::Vec3 _r = _n->getCurrPos() - particle_in->getCurrPos();
        //velocity difference
    ngl::Vec3 _veloDiff = _n->getCurrVelo() - particle_in->getCurrVelo();

    //kernel function
    Kernel kernel(_r, h_in);

    GLfloat _W = kernel.poly(); //POLY

    //formula 4.37
    _correction += (_n->getMass() / (0.5*(particle_in->getDensity()+_n->getDensity()))) * _veloDiff * _W;
  }
  //new velocity
  ngl::Vec3 _newV = particle_in->getCurrVelo() + _correction * epsilon_in;

  //update velocity
  particle_in->updateVelo(_newV);
}

//leap frog integration scheme
void Integrator::leapFrog(Particle * &particle_in)
{
  //update the velo formula 4.34 leap frog
  particle_in->updateVelo(particle_in->getLastVelo() + ((particle_in->getLastAcc() + particle_in->getCurrAcc())/2)*m_deltaTime);
  //update the pos formula 4.33 leap frog
  particle_in->updatePos(particle_in->getLastPos() + (particle_in->getLastVelo() * m_deltaTime) + ((particle_in->getLastAcc()/2)*SQR(m_deltaTime)));
}

//explicit euler integration scheme
void Integrator::explicitEuler(Particle * & particle_in)
{
  //explicit euler integration formula 4.36
  ngl::Vec3 _tempPos = particle_in->getCurrPos() + particle_in->getCurrVelo()*m_deltaTime;
  // formula 4.35
  ngl::Vec3 _tempVelo = particle_in->getCurrVelo() + particle_in->getCurrAcc()*m_deltaTime;

  //update velocity
  particle_in->setVelo(_tempVelo);
  //update the position
  particle_in->setPos(_tempPos);
}

//semi implicit integration scheme
void Integrator::semiImplicitEuler(Particle *&particle_in)
{
  ngl::Vec3 tempPos = particle_in->getCurrPos() + particle_in->getCurrVelo()*m_deltaTime;
  particle_in->updatePos(tempPos);

  ngl::Vec3 tempVelo = particle_in->getCurrVelo() + particle_in->getCurrAcc()*m_deltaTime;
  particle_in->updateVelo(tempVelo);

}

// chech impliciteuler
