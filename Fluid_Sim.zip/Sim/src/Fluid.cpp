#include "Fluid.h"

#define SQR(x)  (x)*(x)

Fluid::Fluid()
{
  //default boolean values for checkbox and data writing features
  m_collisionCondition = false;
  m_writeCheck = true;

  //.obj file paths
  m_boxObjectPath = "models/boxTenMeter.obj";
  m_fluidObjectPath ="models/4ksphere.obj";

  //height of the octree
  m_height = 3;
  //variable to track the id of the particle.
  m_idTrack = 0;

  //smoothing length for SPH
  m_h = 0.3;
  //volume of the fluid object
  m_volume = 21;
  //viscosity coefficient
  m_viscCoeff = 300;
  //gas constant for scalar pressure value
  m_gasConstant = 10;
  //rest density value of the value for all particles
  m_restDensity = 998.2;

}

Fluid::~Fluid()
{
  //clear all the particles
  clearParticles();
  //clear the walls from the scene
  m_myScene.clearWalls();
  //clear the obstacles
  m_sphObstacles.clear();
}

void Fluid::reset()
{
  //clear the partciles
  clearParticles();
  //clear the walls
  m_myScene.clearWalls();
  //delete the hash map
  delete m_hashMap;
}

void Fluid::init()
{
  //set the iteration count to 0
  m_itr = 0;

  //oath initialise the .obj objects
  m_simulationBox = new ngl::Obj(m_boxObjectPath);
  m_fluidObject = new ngl::Obj(m_fluidObjectPath);

  //setting the simulation box dimension and coordinates according to
  //the bounding box from the input simulation box
  m_myScene.setSimulationBox(m_simulationBox);

  //setting the scene features to collision class so the collision detection
  m_collision.setScene(m_myScene);

   //read in the .obj file vertex list to create the fluid object as particles
  BOOST_FOREACH(ngl::Vec3 _vert, m_fluidObject->getVertexList())
  {
    Particle *b = new Particle;
    //set the position of the vertex
    b->setPos(_vert);
    //set the id
    b->setID(m_idTrack);
    //set the mass, this function is used by Kelager (2006)
    b->setMass(m_restDensity*(m_volume/m_fluidObject->getNumVerts()));
    //push the particle to the list
    m_particles.push_back(b);
    ++m_idTrack;
  }

  //create a new hashmap according to the particle count and smoothing length
  m_hashMap = new SpatialHashing(m_particles.size(), m_h);

  //sphere radius for obstacles
  m_sphereRad = 1.0f;
  //sphere collision scenario
  //obstacle sphere creation - basic collision detection
  for(int i = 0; i<2; ++i)
  {
    ngl::Vec3 tempPos(-1+i*2,-2.5,0 );
    m_sphObstacles.push_back(tempPos);
  }

}

void Fluid::calculateDensity()
{
  BOOST_FOREACH(Particle *_p, m_particles)
  {
    //fill the neighbor std::vector for each particle
    //spatial hashing algorithm
    m_hashMap->findNeighbors(_p);

    //set the density to zero since it will be incremented at each neighbor
    _p->setDensity(0);

    BOOST_FOREACH(Particle *_n, _p->getNeighborList())
    {
      ngl::Vec3 _r = _p->getCurrPos() - _n->getCurrPos();
      Kernel kernel(_r, m_h);
      //spline default kernel as defined in mao & yang' (2003) paper
      //_p->addDensity(kernel.spline() * _n->getMass());

      //poly6 default kernel as defined in muller' (2003) paper
      _p->addDensity(kernel.poly() * _n->getMass());
    }
    //calculate scalar pressure values for each particle
    _p->setPressure(0);
    _p->setPressure(m_gasConstant*(_p->getDensity() - m_restDensity));

  }
}

void Fluid::update()
{
  //clear the hash map
  m_hashMap->clearHashmap();

  //fill the hash map
  m_hashMap->fillHashmap(m_particles);

  //calculate densities for each particle
  calculateDensity();

  BOOST_FOREACH(Particle *_p, m_particles)
  {
    //clear force object
    m_particleForces.clearForces();

    //local variables to increase readibility
    ngl::Vec3 pressure, viscosity;

    BOOST_FOREACH(Particle *_n, _p->getNeighborList())
    {
      //if the neighbor and the current particle is not the same
      if(_p->getID()!= _n->getID())
      {
        //get pressure and velocity terms of the particle according to its neighbors
        //equation 10 and 14 from Muller' (2003) paper
        pressure = m_particleForces.getPressure(_p, _n, m_h);
        viscosity = m_particleForces.getViscosity(_p, _n, m_h);
      }


    }

    ngl::Vec3 viscForce, externalForce;
    viscForce = m_viscCoeff*viscosity;
    externalForce = m_particleForces.addGravity();

    //divide with the density value before adding to the net force
    viscForce = viscForce / _p->getDensity();

    ngl::Vec3 acceleration;
    //new acceleration

    //add them all to retrieve the net force
    acceleration = -pressure + viscForce + externalForce ;

    //update the acceleration of the particle
    _p->updateAcc(acceleration);
  }


  //integrate to obtain new positions for the particles
  BOOST_FOREACH(Particle *_p, m_particles)
  {
    //different integration schemes
    //m_integrate.leapFrog(_p);
//    m_integrate.explicitEuler(_p);
   m_integrate.semiImplicitEuler(_p);

    //velocity correction algorithm
    m_integrate.velocityCorrectionXSPH(_p, m_h, 0.25);

    //check for collisions with both the boundaries and the obstacles
    m_collision.checkWalls(_p);
    if(m_collisionCondition)
    {
      m_collision.checkSphere(_p, m_sphObstacles, m_sphereRad);
    }
  }

  //increase iteration
  ++m_itr;
}

void Fluid::clearParticles()
{
  //clear the particle list
  BOOST_FOREACH(Particle *_p, m_particles)
  {
    delete _p;
  }
  m_particles.clear();
}


