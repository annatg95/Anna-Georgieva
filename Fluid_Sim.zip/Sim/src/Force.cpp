#include "Force.h"

#define SQR(x)		(x*x)

Force::Force()
{
  //all force values are initially set to null
  m_pressure.null();
  m_viscosity.null();
  m_external.null();

}

void Force::clearForces()
{
  //clearing all force values
  m_pressure.null();
  m_viscosity.null();
  m_external.null();

}



//calculate the pressure term of the particle
ngl::Vec3 Force::getPressure(const Particle *particle_in, const Particle *n_in, const float h_in)
{

  //position between the current particle and the neighbour particle
  ngl::Vec3 _r = particle_in->getCurrPos() - n_in->getCurrPos();

  //kernel function
  Kernel kernel(_r, h_in);

  //use the spiky kernel stated in mao and yangs, muller' paper
  ngl::Vec3 _W = kernel.gradientSpiky();  //GRADIENT SPIKY

  //pressure calculation
  m_pressure += ((particle_in->getPressure()/SQR((particle_in->getDensity())))+(n_in->getPressure()/SQR((n_in->getDensity())))) *n_in->getMass() * _W;

  return m_pressure;
}

//calculate the viscosity term of the particle
ngl::Vec3 Force::getViscosity(const Particle *particle_in, const Particle *n_in, const float h_in)
{
   //position between the current particle and the neighbour particle
  ngl::Vec3 _r = particle_in->getCurrPos() - n_in->getCurrPos();

  //kernel function
  Kernel kernel(_r, h_in);

  //use the viscosity kernel specified in muller' 2003 paper
  float _W = kernel.viscoLaplacian();

  //velocity between the current particle and neighbour particle
  ngl::Vec3 _vDiff = n_in->getCurrVelo() - particle_in->getCurrVelo();

  //calculate the viscosity
  m_viscosity += _vDiff * (n_in->getMass()/n_in->getDensity()) * _W;

  return m_viscosity;
}

//add gravity to external force
ngl::Vec3 Force::addGravity()
{
    //gravity vector -9.8 on the y
  ngl::Vec3 gravity;
  gravity.set(0, -9.8, 0);

  //apply the external forces
  m_external += gravity;

  return m_external;
}
 //DONE
