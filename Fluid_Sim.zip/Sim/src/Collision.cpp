#include "Collision.h"

Collision::Collision()
{
    //ctor
}

void Collision::setScene(Scene scene_in)
{
  //setting up the scene
  m_myScene = scene_in;
  //initializing the scene
  m_myScene.init();
}

//Checking wall collision function
void Collision::checkWalls(Particle *& particle_in)
{
  //Old Position, Old Velocity, New Position, New Velocity and Wall Normal calculation
  ngl::Vec3 oldP, oldV, newP, newV, wallNormal;
  //radius of the particle
  GLfloat radius;
  //distance to the wall
  GLfloat dist;
  //colour if the wall is hit
  ngl::Colour colour_hit=ngl::Colour(0.8f,0.0f,0.0f,0.0f);

  //take all the parameters needed
  oldP = particle_in->getCurrPos();
  oldV = (particle_in->getLastVelo() + particle_in->getCurrVelo())/2.0;
  radius = particle_in->getRadius();

  //for each wall in all the six walls
  BOOST_FOREACH(Wall *_w, m_myScene.getWalls())
  {
    //if the old velocity is greater than 0
    if(oldV.length() > 0)
    {
      //equation of the plane
      wallNormal.m_x = _w->a;
      wallNormal.m_y = _w->b;
      wallNormal.m_z = _w->c;
      //calculate the distance from the particle to the wall
      dist = oldP.m_x * _w->a + oldP.m_y * _w->b + oldP.m_z * _w->c + _w->d - radius;
      //if the distance is less than zero it means hit
      if(dist < 0.0)
      {
        //calculate the new position
        newP = oldP -3*dist*wallNormal;
        //calculate the new velocity
        newV = (oldV - 1.0*(oldV.dot(wallNormal)*wallNormal));
        //set new position to the current particle
        particle_in->setPos(newP);
        //set new velocity to the current particle
        particle_in->setVelo(newV);
        //set new colour to the current particle
        particle_in->setColour(colour_hit);
      }
    }
  }
}

//Checking sphere collision function
void Collision::checkSphere(Particle *& particle_in, std::vector<ngl::Vec3> obstacle_in, GLfloat radius_in)
{
   //colour if a sphere obstacle is hit
  ngl::Colour colour_hit=ngl::Colour(0.0f,0.0f,0.8f,0.0f);

  //for each position of all positions of the obstacles
  BOOST_FOREACH(ngl::Vec3 _spherePos, obstacle_in)
  {
    //calculate the distance between the obstacle and the particle position
    ngl::Vec3 dist = _spherePos - particle_in->getCurrPos();
    // calculate the collision distance by finding the length of the distance minus the sum of the radius of the obstacle and the particle's radius
    float collisionDistance = dist.length() - (radius_in + particle_in->getRadius());
    //normalize the distance
    dist.normalize();

    //calculate the new position after the collision
    ngl::Vec3 newP = dist * collisionDistance;

    //old velocity, new velocity , normal of the sphere
    ngl::Vec3 oldV, newV, sphereNormal;
    //old velocity calculation
    oldV = (particle_in->getCurrVelo() + particle_in->getLastVelo())/2.0;
    //nomral of the sphere calculation
    sphereNormal = _spherePos - particle_in->getCurrPos();
    //normalizing the sphere normal
    sphereNormal.normalize();

    //if the collision distance is less than 0 it means hit
    if(collisionDistance < 0)
    {
        //calculate the new position
      newP += particle_in->getCurrPos();

      //calculate the new velocity
      newV = (oldV - 1.0*(oldV.dot(sphereNormal)*sphereNormal));

      //set the new position
      particle_in->setPos(newP);

      // set the new velocity
      particle_in->setVelo(newV);

      //set the new colour
      particle_in->setColour(colour_hit);
    }
  }
}



