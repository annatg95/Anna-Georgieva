#include "NGLScene.h"
#include <iostream>
#include <ngl/NGLInit.h>
#include <ngl/VAOPrimitives.h>
#include <ngl/ShaderLib.h>
#include <ngl/Util.h>
#include <ngl/Material.h>
#include <iostream>
#include <ngl/NGLStream.h>

const static float INCREMENT=0.05;
const static float ZOOM=1;

NGLScene::NGLScene(const QGLFormat _format, QWidget *_parent ) : QGLWidget( _format, _parent )
{
  m_rotate=false;
  m_spinXFace=0;
  m_spinYFace=0;
  m_timer_value = 1;
  stopSimulation();
  m_checkDraw = true;
  m_fluidType = true;
  m_width=600;
  m_height=600;
}

NGLScene::~NGLScene()
{

  m_myScene.clearWalls();
}

void NGLScene::drawSpheres(ngl::Vec3 io_obstacle)
{
 ngl::Mat3 normalMatrix;

    //initialize the shaders
  ngl::ShaderLib *shader=ngl::ShaderLib::instance();
  (*shader)["nglDiffuseShader"]->use();
  shader->setUniform("Colour", 0.5f, 0.5f, 0.5f, 0.0f);
  m_transform.reset();
  m_sphere = ngl::VAOPrimitives::instance();
  m_sphere->createSphere("sphere", m_myFluid.getObstacleRadius(), 30);
  m_transform.setPosition(io_obstacle.m_x, io_obstacle.m_y, io_obstacle.m_z);

  //loadMatricesToShader
  ngl::Mat4 MVP= m_cam.getVPMatrix() *m_mouseGlobalTX *m_transform.getMatrix();
  shader->setUniform("MVP",MVP);
  shader->setUniform("normalMatrix",normalMatrix);

  m_sphere->draw("sphere");
}

//draw particles to represent fluids
void NGLScene::drawParticles(ngl::Vec3 io_pos, float io_radius, ngl::Colour io_colour)
{
  ngl::Mat3 normalMatrix;

  ngl::ShaderLib *shader=ngl::ShaderLib::instance();
  (*shader)["nglDiffuseShader"]->use();
    shader->setUniform("Colour",io_colour.m_r,io_colour.m_g,io_colour.m_b,io_colour.m_a);
  ngl::Transformation t;
  t.setPosition(io_pos);
  t.setScale(io_radius,io_radius,io_radius);

  ngl::Mat4 MVP= m_cam.getVPMatrix() *m_mouseGlobalTX *t.getMatrix();
  shader->setUniform("MVP",MVP);
  shader->setUniform("normalMatrix",normalMatrix);

  // get an instance of the VBO primitives for drawing
  ngl::VAOPrimitives::instance()->draw("sphere");

}

//draw all the elements found in the scene
void NGLScene::drawScene()
{
  //draw the particles
  BOOST_FOREACH(Particle *p, m_myFluid.getParticles())
  {
    drawParticles(p->getCurrPos(), p->getRadius(), p->getColour());
  }

  // draw the walls
  ngl::VAOPrimitives *prim=ngl::VAOPrimitives::instance();
  ngl::ShaderLib *shader=ngl::ShaderLib::instance();
  (*shader)["nglColourShader"]->use();
  BOOST_FOREACH(Wall *w, m_myScene.getWalls())
  {
    if(w->draw_flag)
    {
      m_transform.reset();
      {
        shader->setUniform("Colour", 1.0f, 1.0f, 1.0f, 0.0f);
        m_transform.setPosition(w->centre);
        m_transform.setScale(w->size, w->size, w->size);
        m_transform.setRotation(getRotationFromY(ngl::Vec3(w->a,w->b,w->c)));

        ngl::Mat4 MVP= m_cam.getVPMatrix() *m_mouseGlobalTX *m_transform.getMatrix();
        shader->setUniform("MVP",MVP);
        prim->draw("wall");
      }
    }
  }

  if(m_myFluid.getCollisionCondition())
  {
    BOOST_FOREACH(ngl::Vec3 sph, m_myFluid.getObstacles())
    {
      drawSpheres(sph);
    }
  }
}

ngl::Vec3 NGLScene::getRotationFromY(ngl::Vec3 _vec) const
{
    ngl::Vec3 rot;
    rot.m_z = 0.0;
    if(fabs(_vec.m_y)< 0.0001)
    {
        if (_vec.m_z>= 0.0)
            rot.m_x = -90;
        else
            rot.m_x = 90;
    }
    else
        rot.m_x = atan(_vec.m_z/_vec.m_y);
    if(fabs(_vec.m_y) + fabs(_vec.m_z) < 0.0001)
    {
        if(_vec.m_x > 0)
            rot.m_y = -90;
        else
            rot.m_y = 90;
    }
    else
        rot.m_z = atan(_vec.m_x/sqrt(_vec.m_y*_vec.m_y + _vec.m_z*_vec.m_z));

    return rot;
}

void NGLScene::initScene()
{
  //initialise both the fluid and the scene
  m_myFluid.init();
  m_myScene = m_myFluid.getScene();
  m_myScene.init();
}

void NGLScene::resizeGL(QResizeEvent *_event)
{
  m_width=_event->size().width()*devicePixelRatio();
  m_height=_event->size().height()*devicePixelRatio();
  // now set the camera size values as the screen size has changed
  m_cam.setShape(45.0f,(float)width()/height(),0.05f,350.0f);
}

void NGLScene::resizeGL(int _w , int _h)
{
  m_cam.setShape(45.0f,(float)_w/_h,0.05f,350.0f);
  m_width=_w*devicePixelRatio();
  m_height=_h*devicePixelRatio();
}

void NGLScene::initializeGL()
{
    ngl::NGLInit::instance();
    glClearColor(0.4f, 0.4f, 0.4f, 1.0f);
    glEnable(GL_DEPTH_TEST);

    ngl::Vec3 from(0,0,10);
    ngl::Vec3 to(0,0,0);
    ngl::Vec3 up(0,1,0);
    m_cam.set(from,to,up);
    m_cam.setShape(45,(float)720.0/576.0,0.5,150);

    ngl::ShaderLib *shader=ngl::ShaderLib::instance();
    (*shader)["nglDiffuseShader"]->use();
    shader->setUniform("Colour",1.0f,1.0f,0.0f,1.0f);
    shader->setUniform("lightPos",1.0f,1.0f,1.0f);
    shader->setUniform("lightDiffuse",1.0f,1.0f,1.0f,1.0f);

    glEnable(GL_DEPTH_TEST); // for removal of hidden surfaces

    ngl::VAOPrimitives *prim=ngl::VAOPrimitives::instance();
    prim->createSphere("sphere",1.0,20);
    prim->createLineGrid("wall", 1, 1, 5);

    m_text= new ngl::Text(QFont("Arial", 14));

    m_text->setScreenSize(width(),height());

    m_currentTime = m_currentTime.currentTime();
    initScene();
    glViewport(0,0,width(),height());

}

void NGLScene::paintGL()
{
  // clear the screen and depth buffer
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  glViewport(0,0,m_width,m_height);

  QTime newTime = m_currentTime.currentTime();
  int msecpassed = m_currentTime.msecsTo(newTime);
  m_currentTime = newTime;

  // grab an instance of the shader manager
  ngl::ShaderLib *shader=ngl::ShaderLib::instance();
  // clear the screen and depth buffer
  shader->use("nglDiffuseShader");

  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  ngl::Mat4 rotX;
  ngl::Mat4 rotY;
  // create the rotation matrices
  rotX.rotateX(m_spinXFace);
  rotY.rotateY(m_spinYFace);
  // multiply the rotations
  m_mouseGlobalTX=rotY*rotX;
  // add the translations
  m_mouseGlobalTX.m_m[3][0] = m_modelPos.m_x;
  m_mouseGlobalTX.m_m[3][1] = m_modelPos.m_y;
  m_mouseGlobalTX.m_m[3][2] = m_modelPos.m_z;

  //draw the text
  QString text;
  text.sprintf("framerate is %d", (int)(1000.0/msecpassed));
  m_text->renderText(5,5, text);
  text.sprintf("iteration count is %d", (m_myFluid.getItr()));
  m_text->renderText(5,25,text);

  if(m_checkDraw)
  {
    //draw the scene
    drawScene();
  }
}

void NGLScene::mouseMoveEvent (QMouseEvent * _event)
{
    // note the method buttons() is the button state when event was called
    // this is different from button() which is used to check which button was
    // pressed when the mousePress/Release event is generated
    if(m_rotate && _event->buttons() == Qt::LeftButton)
    {
      int diffx=_event->x()-m_origX;
      int diffy=_event->y()-m_origY;
      m_spinXFace += (float) 0.5f * diffy;
      m_spinYFace += (float) 0.5f * diffx;
      m_origX = _event->x();
      m_origY = _event->y();
      update();
    }
    // right mouse translate code
    else if(m_translate && _event->buttons() == Qt::RightButton)
    {
      int diffX = (int)(_event->x() - m_origXPos);
      int diffY = (int)(_event->y() - m_origYPos);
      m_origXPos=_event->x();
      m_origYPos=_event->y();
      m_modelPos.m_x += INCREMENT * diffX;
      m_modelPos.m_y -= INCREMENT * diffY;
      update();
     }

}

void NGLScene::mousePressEvent (QMouseEvent * _event )
{
  // this method is called when the mouse button is pressed in this case we
  // store the value where the maouse was clicked (x,y) and set the Rotate flag to true
  if(_event->button() == Qt::LeftButton)
  {
    m_origX = _event->x();
    m_origY = _event->y();
    m_rotate =true;
  }
  // right mouse translate mode
  else if(_event->button() == Qt::RightButton)
  {
    m_origXPos = _event->x();
    m_origYPos = _event->y();
    m_translate=true;
  }
}

void NGLScene::mouseReleaseEvent (QMouseEvent * _event )
{
  // this event is called when the mouse button is released
  // we then set Rotate to false
  if (_event->button() == Qt::LeftButton)
  {
    m_rotate=false;
  }
        // right mouse translate mode
  if (_event->button() == Qt::RightButton)
  {
    m_translate=false;
  }
}



void NGLScene::wheelEvent(QWheelEvent *_event)
{
    // check the diff of the wheel position (0 means no change)
        if(_event->delta() > 0)
        {
            m_modelPos.m_z+=ZOOM;
        }
        else if(_event->delta() <0 )
        {
            m_modelPos.m_z-=ZOOM;
        }
        update();
}


void NGLScene::timerEvent(QTimerEvent *_event)
{
  if(m_myFluid.getItr() == 3000)
  {
    stopSimulation();
    killTimer(m_timer_value);

  }
  else
  {
  //update functions
  if(m_fluidType)
  {
    m_myFluid.update();
  }
  updateGL();
  }
}

//reset the simultaion, set the parameters from UI to the system
void NGLScene::resetSimulation(const double volume_in, const double h_in, const double viscosity_in, const double density_in, const double gasConst_in)
{
  m_myFluid.setVolume(volume_in);
  m_myFluid.setGasConstant(gasConst_in);
  m_myFluid.setRestDensity(density_in);
  m_myFluid.setSmoothingLength(h_in);
  m_myFluid.setViscosityCoeff(viscosity_in);

  m_myScene.clearWalls();
  m_myFluid.reset();
  initScene();
}


void NGLScene::checkDraw(const int io_check)
{
  if(io_check == 0)
  {
    m_checkDraw = false;
  }
  else
  {
    m_checkDraw = true;
  }
}

//collision condition checkbox function
void NGLScene::collisionCond(const int io_check)
{
  if(io_check == 0)
  {
    m_myFluid.setCollisionCondition(false);
  }
  else
  {
    m_myFluid.setCollisionCondition(true);
  }
}
