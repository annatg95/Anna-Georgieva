#include "MainWindow.h"
#include "ui_MainWindow.h"
#include <QApplication>
#include <QFileDialog>
#include <QDir>

MainWindow::MainWindow(QWidget *parent) :QMainWindow(parent),  m_ui(new Ui::MainWindow)
{
    m_ui->setupUi(this);
    // create an openGL format and pass to the new GLWidget
    QGLFormat format;
    format.setVersion(3,2);
    format.setProfile(QGLFormat::CoreProfile);

    m_gl=new NGLScene(format, this);


    //screen element
    m_ui->screen->addWidget(m_gl,0,0,12,1);
    //run/pause button
    connect(m_ui->runButton, SIGNAL(clicked(bool)), this, SLOT(run(bool)));
    connect(m_ui->resetButton, SIGNAL(clicked()), this, SLOT(reset()));

    //fluid elements
    connect(m_ui->newGasConstantBox, SIGNAL(valueChanged(double)), m_gl, SLOT(uisetGasConstant(double)));
    connect(m_ui->newVolumeBox, SIGNAL(valueChanged(double)), m_gl, SLOT(uiSetVolume(double)));
    connect(m_ui->newSmoothBox, SIGNAL(valueChanged(double)), m_gl, SLOT(uiSetSmoothingLength(double)));
    connect(m_ui->newViscoBox, SIGNAL(valueChanged(double)), m_gl, SLOT(uisetViscosityCoeff(double)));
    connect(m_ui->newDensityBox, SIGNAL(valueChanged(double)), m_gl, SLOT(uisetRestDensity(double)));

    //opengl draw checkbox and collision condition
    connect(m_ui->openglCheckBox, SIGNAL(stateChanged(int)), m_gl, SLOT(checkDraw(int)));
    connect(m_ui->collisionCheckBox, SIGNAL(stateChanged(int)), m_gl, SLOT(collisionCond(int)));

}

//dtor
MainWindow::~MainWindow()
{
    delete m_ui;
}

//run or stop the simulation according to the boolean value
void MainWindow::run(bool io_simRun)
{

  if(io_simRun)
  {
    m_gl->runSimulation();
  }
  else
  {
    m_gl->stopSimulation();
  }
}

//reset the simulation
void MainWindow::reset()
{
    m_gl->resetSimulation(m_ui->newVolumeBox->value(),
                          m_ui->newSmoothBox->value(),
                          m_ui->newViscoBox->value(),
                          m_ui->newDensityBox->value(),
                          m_ui->newGasConstantBox->value());

}

