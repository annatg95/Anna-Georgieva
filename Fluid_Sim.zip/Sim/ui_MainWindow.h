/********************************************************************************
** Form generated from reading UI file 'MainWindow.ui'
**
** Created by: Qt User Interface Compiler version 5.9.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QWidget *layoutWidget;
    QGridLayout *screen;
    QPushButton *runButton;
    QPushButton *resetButton;
    QCheckBox *openglCheckBox;
    QCheckBox *collisionCheckBox;
    QWidget *verticalLayoutWidget;
    QVBoxLayout *verticalLayout;
    QLabel *label_8;
    QDoubleSpinBox *newGasConstantBox;
    QLabel *label_4;
    QDoubleSpinBox *newViscoBox;
    QLabel *label_3;
    QDoubleSpinBox *newSmoothBox;
    QLabel *label_5;
    QDoubleSpinBox *newVolumeBox;
    QLabel *label_15;
    QDoubleSpinBox *newDensityBox;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(1000, 600);
        MainWindow->setLayoutDirection(Qt::LeftToRight);
        MainWindow->setAutoFillBackground(true);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QStringLiteral("centralwidget"));
        layoutWidget = new QWidget(centralwidget);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(8, 8, 721, 581));
        screen = new QGridLayout(layoutWidget);
        screen->setObjectName(QStringLiteral("screen"));
        screen->setSizeConstraint(QLayout::SetNoConstraint);
        screen->setContentsMargins(0, 0, 0, 0);
        runButton = new QPushButton(centralwidget);
        runButton->setObjectName(QStringLiteral("runButton"));
        runButton->setEnabled(true);
        runButton->setGeometry(QRect(770, 550, 93, 27));
        runButton->setCheckable(true);
        runButton->setChecked(false);
        resetButton = new QPushButton(centralwidget);
        resetButton->setObjectName(QStringLiteral("resetButton"));
        resetButton->setGeometry(QRect(870, 550, 93, 27));
        openglCheckBox = new QCheckBox(centralwidget);
        openglCheckBox->setObjectName(QStringLiteral("openglCheckBox"));
        openglCheckBox->setGeometry(QRect(740, 520, 121, 21));
        openglCheckBox->setCheckable(true);
        openglCheckBox->setChecked(true);
        collisionCheckBox = new QCheckBox(centralwidget);
        collisionCheckBox->setObjectName(QStringLiteral("collisionCheckBox"));
        collisionCheckBox->setGeometry(QRect(850, 520, 151, 20));
        verticalLayoutWidget = new QWidget(centralwidget);
        verticalLayoutWidget->setObjectName(QStringLiteral("verticalLayoutWidget"));
        verticalLayoutWidget->setGeometry(QRect(740, 10, 241, 437));
        verticalLayout = new QVBoxLayout(verticalLayoutWidget);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        label_8 = new QLabel(verticalLayoutWidget);
        label_8->setObjectName(QStringLiteral("label_8"));

        verticalLayout->addWidget(label_8);

        newGasConstantBox = new QDoubleSpinBox(verticalLayoutWidget);
        newGasConstantBox->setObjectName(QStringLiteral("newGasConstantBox"));
        newGasConstantBox->setDecimals(1);
        newGasConstantBox->setValue(10);

        verticalLayout->addWidget(newGasConstantBox);

        label_4 = new QLabel(verticalLayoutWidget);
        label_4->setObjectName(QStringLiteral("label_4"));

        verticalLayout->addWidget(label_4);

        newViscoBox = new QDoubleSpinBox(verticalLayoutWidget);
        newViscoBox->setObjectName(QStringLiteral("newViscoBox"));
        newViscoBox->setDecimals(0);
        newViscoBox->setMaximum(10000);
        newViscoBox->setValue(300);

        verticalLayout->addWidget(newViscoBox);

        label_3 = new QLabel(verticalLayoutWidget);
        label_3->setObjectName(QStringLiteral("label_3"));

        verticalLayout->addWidget(label_3);

        newSmoothBox = new QDoubleSpinBox(verticalLayoutWidget);
        newSmoothBox->setObjectName(QStringLiteral("newSmoothBox"));
        newSmoothBox->setDecimals(1);
        newSmoothBox->setValue(0.3);

        verticalLayout->addWidget(newSmoothBox);

        label_5 = new QLabel(verticalLayoutWidget);
        label_5->setObjectName(QStringLiteral("label_5"));

        verticalLayout->addWidget(label_5);

        newVolumeBox = new QDoubleSpinBox(verticalLayoutWidget);
        newVolumeBox->setObjectName(QStringLiteral("newVolumeBox"));
        newVolumeBox->setDecimals(1);
        newVolumeBox->setMaximum(10000);
        newVolumeBox->setValue(21);

        verticalLayout->addWidget(newVolumeBox);

        label_15 = new QLabel(verticalLayoutWidget);
        label_15->setObjectName(QStringLiteral("label_15"));

        verticalLayout->addWidget(label_15);

        newDensityBox = new QDoubleSpinBox(verticalLayoutWidget);
        newDensityBox->setObjectName(QStringLiteral("newDensityBox"));
        newDensityBox->setDecimals(1);
        newDensityBox->setMaximum(10000);
        newDensityBox->setValue(998.2);

        verticalLayout->addWidget(newDensityBox);

        MainWindow->setCentralWidget(centralwidget);

        retranslateUi(MainWindow);

        runButton->setDefault(false);


        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", Q_NULLPTR));
        runButton->setText(QApplication::translate("MainWindow", "Run/Pause", Q_NULLPTR));
        resetButton->setText(QApplication::translate("MainWindow", "Reset", Q_NULLPTR));
        openglCheckBox->setText(QApplication::translate("MainWindow", "Draw Scene", Q_NULLPTR));
        collisionCheckBox->setText(QApplication::translate("MainWindow", "Collision Condition", Q_NULLPTR));
        label_8->setText(QApplication::translate("MainWindow", "Gas Constant", Q_NULLPTR));
        label_4->setText(QApplication::translate("MainWindow", "Viscosity Coeff.", Q_NULLPTR));
        label_3->setText(QApplication::translate("MainWindow", "Smoothing Length", Q_NULLPTR));
        label_5->setText(QApplication::translate("MainWindow", "Volume", Q_NULLPTR));
        label_15->setText(QApplication::translate("MainWindow", "Rest Density", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
