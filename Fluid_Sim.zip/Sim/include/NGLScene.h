#ifndef NGLSCENE_H__
#define NGLSCENE_H__

#include <ngl/Camera.h>
#include <ngl/Transformation.h>
#include <QEvent>
#include <QResizeEvent>
#include <QGLWidget>
#include <ngl/Light.h>
#include "Fluid.h"
#include "Scene.h"
#include "ngl/VAOPrimitives.h"
#include "QTime"
#include "ngl/Text.h"

/// @brief GLWindow class is created to be the bridge between the structure and the visualization of the code
class NGLScene : public QGLWidget
{
     Q_OBJECT        // must include this if you use Qt signals/slots
    public :
        NGLScene(const QGLFormat _format,QWidget *_parent );
        ~NGLScene();
        void resizeGL(QResizeEvent *_event);
        void resizeGL(int _w, int _h);
        void initializeGL();
        void paintGL();
        void initScene();
        void setScene(Scene scene_in);

    public slots:
        inline void runSimulation() {timer = startTimer(m_timer_value);}
        inline void stopSimulation() {killTimer(timer);}
        void resetSimulation(const double volume_in, const double h_in, const double viscosity_in, const double density_in,
                           const double gasConst_in);

        inline void uiSetVolume(const double volume_in) {m_myFluid.setVolume(volume_in);}
        inline void uiSetSmoothingLength(const double h_in) {m_myFluid.setSmoothingLength(h_in);}
        inline void uisetViscosityCoeff(const double viscosity_in) {m_myFluid.setViscosityCoeff(viscosity_in);}
        inline void uisetRestDensity(const double density_in) {m_myFluid.setRestDensity(density_in);}
        inline void uisetGasConstant(const double gasConst_in) {m_myFluid.setGasConstant(gasConst_in);}

        void checkDraw(const int io_check);
        void collisionCond(const int io_check);

    private:
        int timer;
        int m_timer_value;
        int m_spinXFace;
        int m_spinYFace;
        bool m_rotate;
        bool m_translate;
        int m_origX;
        int m_origY;
        int m_origXPos;
        int m_origYPos;
        int m_width;
        int m_height;

        ngl::Mat4 m_mouseGlobalTX;
        ngl::Camera m_cam;
        ngl::Transformation m_transform;
        ngl::Vec3 m_modelPos;
        QTime m_currentTime;
        ngl::Text *m_text;
        ngl::VAOPrimitives *m_sphere;

        void mouseMoveEvent (QMouseEvent * _event);
        void mousePressEvent (QMouseEvent *_event);
        void mouseReleaseEvent (QMouseEvent *_event);

        void timerEvent(QTimerEvent *_event);
        void wheelEvent( QWheelEvent *_event);

        ngl::Vec3 getRotationFromY(ngl::Vec3 _vec) const;
        bool m_checkDraw, m_fluidType;
        void drawParticles(ngl::Vec3 io_pos, float io_rad, ngl::Colour io_c);
        void drawScene();
        void drawSpheres(ngl::Vec3 io_obstacle);
        Fluid m_myFluid;
        Scene m_myScene;
};

#endif
//done
