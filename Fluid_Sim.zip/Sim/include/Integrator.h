#ifndef INTEGRATOR_H
#define INTEGRATOR_H

#include "Particle.h"
#include "Kernel.h"
#include "boost/foreach.hpp"

/// Explicit integration methods implemented: leap-frog, explicit Euler
/// XSPH Velocity correction (Monaghan, 1989)
/// @brief Integrator class to calculate the new position and velocity values by integrating the previous ones
class Integrator
{
    public:
    //@biref constructor of the class
        Integrator();

        //@brief get deltaTime
        inline GLfloat getTimestep() const {return m_deltaTime;}

        //@brief set the delta time
        //@params delta time value in
        inline void setTimestep(const float timestep_in) {m_deltaTime = timestep_in;}

        //@brief leap frog function
        //@param current particle
        void leapFrog(Particle * & particle_in);

        //@brief explicit euler function
        //@param current particle
        void explicitEuler(Particle * & particle_in);

        //@brief semi implicit euler function
        //@param current particle
        void semiImplicitEuler(Particle * & particle_in);

        //@brief velocity correction xsph function
        //@param current particle, height of the octree, epsilon value
        void velocityCorrectionXSPH(Particle * & particle_in, const float h_in, const float epsilon_in);
    private:

        //delta time value
        GLfloat m_deltaTime;
};

#endif // INTEGRATOR_H

