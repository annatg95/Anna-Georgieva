#ifndef COLLISION_H
#define COLLISION_H

#include "Scene.h"
#include "Particle.h"
#include "Integrator.h"


///@brief Collision Detection class
///Checking two types of collision against a wall or a sphere
class Collision
{
    public:
        //@brief construtor of the collision class
        Collision();

        //@brief setting up the scene
        //@params scene which contains the Collision BOX
        void setScene(Scene scene_in);

        //@brief checking collisions with walls
        //@params takes the current particle
        void checkWalls(Particle *& particle_in);

        //@brief checking collision with spheres
        //@params takes current particle, obstacle's posiition and the radius of the obstacle
        void checkSphere(Particle *& particle_in, std::vector<ngl::Vec3> obstacle_in, GLfloat radius_in);

    private:
        //@attribute scene object
        Scene m_myScene;
 };

#endif // COLLISION_H

