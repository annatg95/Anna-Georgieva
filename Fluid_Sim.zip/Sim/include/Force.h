#ifndef FORCE_H
#define FORCE_H

#include "Particle.h"
#include "Kernel.h"
#include "boost/foreach.hpp"

/// @brief Force class to calculate the pressure, viscosity, gravity
/// for Newtonian fluids
class Force
{
    public:
        //@brief constructor of the class
        Force();

        //@brief get pressure
        //@params  current particle, neighbour particlem, height of the octree
        ngl::Vec3 getPressure(const Particle *particle_in, const Particle *n_in, const float h_in);

        //@brief get viscosity
        //@params  current particle, neighbour particle, height of the octree
        ngl::Vec3 getViscosity(const Particle *particle_in, const Particle *n_in, const float h_in);

        //@brief add gravity to the scene
        ngl::Vec3 addGravity();

        //@brief  get external forces
        inline ngl::Vec3 getExternal() const {return m_external;}

        //@brief clear forces
        void clearForces();

    private:
        //forces values: pressure, viscosity, external forces
        ngl::Vec3 m_pressure, m_viscosity, m_external;

};

#endif // FORCE_H

