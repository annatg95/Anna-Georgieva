#ifndef SPATIALHASHING_H
#define SPATIALHASHING_H

#include "Particle.h"
#include "map"
#include "boost/foreach.hpp"
#include "Scene.h"
#include <ngl/NGLStream.h>

/// This class is written based on the paper of Teschner 2003. However it also contains in influences
/// of Kelager's (2006) and Priscott's (2010) work as well.
///------------------------------------------------------------------------------------------------------------

/// @brief SpatialHashing class is where neighbor searching is done
class SpatialHashing
{
    public:
        //@brief constructor of the class
        //@param particle count, octree height
        SpatialHashing(const int io_partCount, const float io_h);

        //@brief destructor
        ~SpatialHashing();

        //@brief find the neighbours of the particle
        //@param current particle
        void findNeighbors(Particle * & io_p);

        //@brief search the map of keys
        //@param current particle, key related to the particle
        void searchMap(Particle * & io_p, const int io_key);

        //@brief check list
        //@param pass the particle's key
        bool checkList(const int io_key);

        //@brief assign keys to the particles
        //@param arary of particles
        void fillHashmap(std::vector<Particle *> io_particles);

        //@brief clear the hashmap
        inline void clearHashmap() { m_map.clear(); }

        //@brief get the key of the particle
        //@param pass the position
        int getKey(const ngl::Vec3 io_pos);

        //@brief modulo calculation
        int mod(const int io_a, const int io_b);

        //@brief discretize function
        //@param pass the postition
        ngl::Vec3 discretize(const ngl::Vec3 io_pos);

        //@brief prime check for keys generation
        //@param takes a number
        bool isPrime(const int io_num);

        //@brief check for the next prime
        //@param takes a number
        int nextPrime(int io_num);
    private:
        //multimap that assigns key value to the particles
        typedef std::multimap<int, Particle *> hashmap;

        //map that has two numbers comparing the particles pos id
        typedef std::map<int, int> ID_hashmap;

        //hashmap
        hashmap m_map;

        //id hashmap
        ID_hashmap m_idMap;

        //cell size
        float m_cellSize;

        //large prime numbers
        int m_p1, m_p2, m_p3, m_n;
};

#endif // SPATIALHASHING_H
