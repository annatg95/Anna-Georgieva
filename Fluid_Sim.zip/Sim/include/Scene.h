#ifndef SCENE_H
#define SCENE_H

#include "Particle.h"
#include "boost/foreach.hpp"
#include "ngl/Obj.h"

//wall=plane structure
typedef struct WALL{
    ngl::Vec3   centre;
    float   size;
    float   a;
    float   b;
    float   c;
    float   d;
    bool    draw_flag;
} Wall;

//cube attributes
class Cube
{
    public:
        float m_minx, m_maxx, m_miny, m_maxy, m_minz, m_maxz;
};

//Jon Macey's OctreeAbstract Demo.
class Scene
{
    public:
        //@brief initialize the scene
        void init();

        //@brief define the obj that represents the cube
        //@param obj file
        void setSimulationBox(ngl::Obj * io_obj);

        //@brief add the walls to form the cube
        void addWall(ngl::Vec3 io_point, float io_size, ngl::Vec3 io_normal, bool io_draw);

        //@brief clear the walls
        void clearWalls();

        //@brief  get the array of walls of the cube
        inline std::vector <Wall *> getWalls() const {return m_walls;}

        //@brief get the cube
        inline Cube getBBCube() const {return m_simBox;}
    private:
        //array of walls
        std::vector <Wall *> m_walls;

        //box
        Cube m_simBox;
};

#endif // SCENE_H

