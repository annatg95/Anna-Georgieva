#ifndef FLUID_H
#define FLUID_H

#include "Force.h"
#include "Kernel.h"
#include "Integrator.h"
#include "SpatialHashing.h"
#include <ngl/NGLStream.h>
#include "Scene.h"
#include "Collision.h"
#include "ngl/Obj.h"

///@brief Fluid class that gathers all the calculations done by other classes and creates the result

class Fluid
{
    public:
        //@brief construtor of the class
        Fluid();

        //@brief destructor of the class
        ~Fluid();

        //clear the particles
        void clearParticles();

        //@brief initialize the fluid
        void init();

        //@brief update the fluid
        void update();

        //@brief reset the fluid
        void reset();

        //@brief calculate Density of the fluid
        void calculateDensity();

        //@brief get Particle array
        inline std::vector<Particle *> getParticles() const {return m_particles;}

        //@brief get iterator counter for the particles
        inline int getItr() const {return m_itr;}

        //@brief get the scene in which the particles are dropped
        inline Scene getScene() const {return m_myScene;}

        //@brief set the volume of the fluid
        //@param volume value
        inline void setVolume(const GLdouble volume_in) {m_volume = volume_in;}

        //@brief set the smoothing length
        //@param smoothing value
        inline void setSmoothingLength(const GLdouble h_in) {m_h = h_in;}

        //@brief set viscosity coefficient
        //@param viscosity value
        inline void setViscosityCoeff(const GLdouble viscosity_in) {m_viscCoeff = viscosity_in;}

        //@brief set rest density
        //@param rest density value
        inline void setRestDensity(const GLdouble density_in) {m_restDensity = density_in;}

        //@brief set gas constant
        //@param gas constant value
        inline void setGasConstant(const GLdouble gasConst_in) {m_gasConstant = gasConst_in;}

        //@brief get obstacles
        inline std::vector<ngl::Vec3> getObstacles() const {return m_sphObstacles;}

        //@brief get obstacle radius
        inline float getObstacleRadius() const {return m_sphereRad;}

        //@brief choice of the user in terms of the sphere obstacles
        //@params checkbox choice
        inline void setCollisionCondition(const GLboolean io_condition) {m_collisionCondition = io_condition;}

        //@brief get the collision preference defined by the user
        inline bool getCollisionCondition() const {return m_collisionCondition;}

        //file path of the box object and the fluid object
        std::string m_boxObjectPath, m_fluidObjectPath;

    private:
        //all the attributes of the fluid
        // m_h - smoothing length; viscosity, elasticy, relaxation, volume
        //      - gas constant, rest density and radius of the obstacle
        GLfloat m_h, m_viscCoeff, m_elasticity, m_relaxation, m_volume, m_gasConstant, m_restDensity, m_sphereRad;
      //height of the octree, counter iterator and id number of the particle
        GLint m_height, m_itr, m_idTrack;

        //fluid object and box object
        ngl::Obj *m_fluidObject;
        ngl::Obj *m_simulationBox;

        //check box conditions drawing scene and collision conditions
        GLboolean m_collisionCondition, m_writeCheck;

        //array of particles
        std::vector <Particle *> m_particles;
        //array of obstacles
        std::vector <ngl::Vec3> m_sphObstacles;

        //hashmap object
        SpatialHashing *m_hashMap;

        //scene object
        Scene m_myScene;

        //integrator object
        Integrator m_integrate;

        //forces acting on the fluid object
        Force m_particleForces;

        //collision object
        Collision m_collision;

};


#endif // FLUID_H
