#ifndef KERNEL_H
#define KERNEL_H

#include "ngl/Vec3.h"

/// @brief Kernel class to calculate the different values of different kernel functions
class Kernel
{
    public:
        //@brief kernel constructor
        //@params  distance between two particles, smoothing length
        Kernel(const ngl::Vec3 r_in, const GLfloat h_in);

        //@brief spline kernel
        GLfloat spline();

         //@brief gradient spline kernel
        ngl::Vec3 gradientSpline();

         //@brief laplacian kernel
        GLfloat viscoLaplacian();

         //@brief spiky kernel
        ngl::Vec3 gradientSpiky();

         //@brief poly kernel
        GLfloat poly();

         //@brief gradient poly kernel
        ngl::Vec3 gradientPoly();

    //@brief laplacian kernel
        GLfloat laplacianPoly();

    private:
        //distance between two particles
        ngl::Vec3 m_r;
        //smoothing length
        GLfloat m_h;
};

#endif // KERNEL_H

