#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "NGLScene.h"
//------------------------------------------------------------------------------------------------------------

namespace Ui {
    class MainWindow;
}

/// @brief a class for visualization elements
class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
  explicit MainWindow(QWidget *parent = 0);
  ~MainWindow();
private:
  Ui::MainWindow *m_ui;
  NGLScene *m_gl;

private slots :
  void run(bool io_simRun);
  void reset();


};

#endif
