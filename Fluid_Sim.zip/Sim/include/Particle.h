#ifndef PARTICLE_H
#define PARTICLE_H

#include <ngl/Vec3.h>
#include <ngl/Colour.h>
#include <ngl/Transformation.h>
#include <ngl/ShaderLib.h>
#include <ngl/VAOPrimitives.h>

/// @brief Particle class that represents the fluid particles. All values that are needed throughout
/// the implementation by any particle are defined in this class. Position, velocity, neighbor list,
/// density, pressure
class Particle
{
     public:
        //@brief constructor of the class
        Particle();

        //@brief destructor
        ~Particle();

        //@brief set position of the particle
        //@param position in
        inline void setPos(ngl::Vec3 io_posIn) {m_currPos = io_posIn; m_lastPos = io_posIn;}

        //@brief set velocity of the particle
        //@param velocity in
        inline void setVelo(ngl::Vec3 io_veloIn) {m_currVelo = io_veloIn; m_lastVelo = io_veloIn;}

        //@brief set acceleration of the particle
        //@param acceleration in
        inline void setAcc(ngl::Vec3 io_accIn) {m_lastAcc = io_accIn; m_currAcc = io_accIn;}

        //@brief update position of the particle
        //@param position in
        void updatePos(ngl::Vec3 io_posIn);

        //@brief update velocity of the particle
        //@param velocity in
        void updateVelo(ngl::Vec3 io_veloIn);

        //@brief update acceleration of the particle
        //@param acceleration in
        void updateAcc(ngl::Vec3 io_accIn);

       //@brief get position of the particle
        inline ngl::Vec3 getCurrPos() const {return m_currPos;}

        //@brief get velocity of the particle
        inline ngl::Vec3 getCurrVelo() const {return m_currVelo;}

        //@brief get acceleration of the particle
        inline ngl::Vec3 getCurrAcc() const {return m_currAcc;}

        //@brief get position of the particle
        inline ngl::Vec3 getLastPos() const {return m_lastPos;}

        //@brief get velocity of the particle
        inline ngl::Vec3 getLastVelo() const {return m_lastVelo;}

         //@brief get acceleration of the particle
        inline ngl::Vec3 getLastAcc() const {return m_lastAcc;}

          //@brief set counting number of the particle
        inline void setID(const int io_id) {m_id=io_id;}

         //@brief set radius of the particle
        inline void setRad(const float io_rad) {m_radius=io_rad;}

        //@brief add density to the particle
        inline void addDensity(const float io_dens) {m_density += io_dens;}

         //@brief set scalar pressure to the particle
        inline void setPressure(const float io_scaPres) {m_Pres = io_scaPres;}

         //@brief set mass to the particle
        inline void setMass(const float io_m) {m_mass = io_m;}

         //@brief set density to the particle
        inline void setDensity(const float io_dens) {m_density = io_dens;}

         //@brief get counter number to the particle
        inline int getID() const {return m_id;}

         //@brief get colour of the particle
        inline ngl::Colour getColour() const {return m_colour;}

        //@brief set colour of the particle
        //@param colour in
        inline void setColour(const ngl::Colour io_col) {m_colour = io_col;}

        //@brief get mass of the particle
        inline float getMass() const {return m_mass;}

        //@brief get density of the particle
        inline float getDensity() const {return m_density;}

        //@brief get pressure of the particle
        inline float getPressure() const {return m_Pres;}

        //@brief get radius of the particle
        inline float getRadius() const {return m_radius;}

        //@brief get array of the neighbourhood particles
        inline std::vector<Particle *> getNeighborList() const {return m_neighbor;}

        //@brief add a particle to the neighbourhood array
        void pushToNeighborList(Particle * io_p);

        //@brief clear the array of neighbourhood of particles
        inline void clearNeighborList() {m_neighbor.clear();}
    private:
        //array of neighbours
        std::vector<Particle *> m_neighbor;

        //id counter
        int m_id;

        //mass density radius and pressure
        float m_mass, m_density, m_radius, m_Pres;

        //colour
        ngl::Colour m_colour;

        //last position, current position, last velocity, current velocity, last aceleration, current acceleration
        ngl::Vec3 m_lastPos,  m_currPos, m_lastVelo, m_currVelo, m_lastAcc, m_currAcc;

};

#endif // PARTICLE_H
