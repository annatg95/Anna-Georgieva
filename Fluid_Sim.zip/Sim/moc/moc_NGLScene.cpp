/****************************************************************************
** Meta object code from reading C++ file 'NGLScene.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../include/NGLScene.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'NGLScene.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_NGLScene_t {
    QByteArrayData data[18];
    char stringdata0[226];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_NGLScene_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_NGLScene_t qt_meta_stringdata_NGLScene = {
    {
QT_MOC_LITERAL(0, 0, 8), // "NGLScene"
QT_MOC_LITERAL(1, 9, 13), // "runSimulation"
QT_MOC_LITERAL(2, 23, 0), // ""
QT_MOC_LITERAL(3, 24, 14), // "stopSimulation"
QT_MOC_LITERAL(4, 39, 15), // "resetSimulation"
QT_MOC_LITERAL(5, 55, 9), // "volume_in"
QT_MOC_LITERAL(6, 65, 4), // "h_in"
QT_MOC_LITERAL(7, 70, 12), // "viscosity_in"
QT_MOC_LITERAL(8, 83, 10), // "density_in"
QT_MOC_LITERAL(9, 94, 11), // "gasConst_in"
QT_MOC_LITERAL(10, 106, 11), // "uiSetVolume"
QT_MOC_LITERAL(11, 118, 20), // "uiSetSmoothingLength"
QT_MOC_LITERAL(12, 139, 19), // "uisetViscosityCoeff"
QT_MOC_LITERAL(13, 159, 16), // "uisetRestDensity"
QT_MOC_LITERAL(14, 176, 16), // "uisetGasConstant"
QT_MOC_LITERAL(15, 193, 9), // "checkDraw"
QT_MOC_LITERAL(16, 203, 8), // "io_check"
QT_MOC_LITERAL(17, 212, 13) // "collisionCond"

    },
    "NGLScene\0runSimulation\0\0stopSimulation\0"
    "resetSimulation\0volume_in\0h_in\0"
    "viscosity_in\0density_in\0gasConst_in\0"
    "uiSetVolume\0uiSetSmoothingLength\0"
    "uisetViscosityCoeff\0uisetRestDensity\0"
    "uisetGasConstant\0checkDraw\0io_check\0"
    "collisionCond"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_NGLScene[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      10,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,   64,    2, 0x0a /* Public */,
       3,    0,   65,    2, 0x0a /* Public */,
       4,    5,   66,    2, 0x0a /* Public */,
      10,    1,   77,    2, 0x0a /* Public */,
      11,    1,   80,    2, 0x0a /* Public */,
      12,    1,   83,    2, 0x0a /* Public */,
      13,    1,   86,    2, 0x0a /* Public */,
      14,    1,   89,    2, 0x0a /* Public */,
      15,    1,   92,    2, 0x0a /* Public */,
      17,    1,   95,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Double, QMetaType::Double, QMetaType::Double, QMetaType::Double, QMetaType::Double,    5,    6,    7,    8,    9,
    QMetaType::Void, QMetaType::Double,    5,
    QMetaType::Void, QMetaType::Double,    6,
    QMetaType::Void, QMetaType::Double,    7,
    QMetaType::Void, QMetaType::Double,    8,
    QMetaType::Void, QMetaType::Double,    9,
    QMetaType::Void, QMetaType::Int,   16,
    QMetaType::Void, QMetaType::Int,   16,

       0        // eod
};

void NGLScene::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        NGLScene *_t = static_cast<NGLScene *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->runSimulation(); break;
        case 1: _t->stopSimulation(); break;
        case 2: _t->resetSimulation((*reinterpret_cast< const double(*)>(_a[1])),(*reinterpret_cast< const double(*)>(_a[2])),(*reinterpret_cast< const double(*)>(_a[3])),(*reinterpret_cast< const double(*)>(_a[4])),(*reinterpret_cast< const double(*)>(_a[5]))); break;
        case 3: _t->uiSetVolume((*reinterpret_cast< const double(*)>(_a[1]))); break;
        case 4: _t->uiSetSmoothingLength((*reinterpret_cast< const double(*)>(_a[1]))); break;
        case 5: _t->uisetViscosityCoeff((*reinterpret_cast< const double(*)>(_a[1]))); break;
        case 6: _t->uisetRestDensity((*reinterpret_cast< const double(*)>(_a[1]))); break;
        case 7: _t->uisetGasConstant((*reinterpret_cast< const double(*)>(_a[1]))); break;
        case 8: _t->checkDraw((*reinterpret_cast< const int(*)>(_a[1]))); break;
        case 9: _t->collisionCond((*reinterpret_cast< const int(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObject NGLScene::staticMetaObject = {
    { &QGLWidget::staticMetaObject, qt_meta_stringdata_NGLScene.data,
      qt_meta_data_NGLScene,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *NGLScene::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *NGLScene::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_NGLScene.stringdata0))
        return static_cast<void*>(const_cast< NGLScene*>(this));
    return QGLWidget::qt_metacast(_clname);
}

int NGLScene::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QGLWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 10)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 10;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 10)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 10;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
